import React, { createContext, useState, useEffect } from 'react';

import { Plugins } from '@capacitor/core';

export interface Migraine {
    date : string;
    description : string;
}

export interface Migraines {
    migraines : Migraine[];
}

const { Storage } = Plugins;

export async function saveMigraines(ms : Migraine[]) {
    await Storage.set({
        key: 'migraines',
        value: JSON.stringify(ms)
    });
}

let MigrainesContext = createContext({} as Migraines);

function MigrainesContextProvider(props: { children: React.ReactNode; }) {
    
    const [initialMigraines, setInitialMigraines] = useState([] as Migraine[]);

    useEffect(() => {
        Promise.resolve(Storage.get({key: 'migraines'}).then(
            (result) => {
                if (typeof result.value === 'string') {
                    setInitialMigraines(JSON.parse(result.value) as Migraine[]);
                }
            },
            (reason) => console.log("Failed to load migraines from storage because of: " + reason)
        ));
    }, []); // Nifty trick with useEffect from: https://css-tricks.com/run-useeffect-only-once/

    return (
        <MigrainesContext.Provider value={{migraines : initialMigraines}}>{props.children}</MigrainesContext.Provider>
    )
}

let MigrainesContextConsumer = MigrainesContext.Consumer;

export { MigrainesContext, MigrainesContextProvider, MigrainesContextConsumer };
