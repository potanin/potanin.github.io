import React from 'react';
import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Highlights.css';

const Highlights: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Highlights</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">Highlights</IonTitle>
          </IonToolbar>
        </IonHeader>
        <ExploreContainer name="Highlights Page" />
      </IonContent>
    </IonPage>
  );
};

export default Highlights;
