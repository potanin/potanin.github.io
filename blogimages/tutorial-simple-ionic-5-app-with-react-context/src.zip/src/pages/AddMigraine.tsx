import React from 'react';
import { IonButton, IonInput, IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import './AddMigraine.css';

import { saveMigraines, Migraines, MigrainesContextConsumer } from '../MigrainesState';

const AddMigraine: React.FC = () => {
  var date : string;
  var description : string;
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Add Migraine</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">Add Migraine</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonInput placeholder="Migraine Date" onIonChange={e => date = e.detail.value!}></IonInput>
        <IonInput placeholder="Migraine Description" onIonChange={e => description = e.detail.value!}></IonInput>
        <MigrainesContextConsumer>
          {(context : Migraines) => (
            <IonButton onClick={e =>
            {
              context.migraines ? context.migraines.push({date : date, description : description}) :
                                  context.migraines = [{date : date, description : description}]
              saveMigraines(context.migraines);
            }
            }>Add New Migraine</IonButton>
          )}
        </MigrainesContextConsumer>
      </IonContent>
    </IonPage>
  );
};

export default AddMigraine;
