import React from 'react';
import { IonItemOptions, IonItemOption, IonItemSliding, IonList, IonItem, IonLabel,
         IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import uuid from 'uuid';
import './ListMigraines.css';

import { saveMigraines, Migraine, Migraines, MigrainesContextConsumer } from '../MigrainesState';

const ListMigraines: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>List Migraines</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">List Migraines</IonTitle>
          </IonToolbar>
        </IonHeader>
        <MigrainesContextConsumer>
          { (context : Migraines) =>
          <IonList>
            <IonItem><IonLabel>Total Number of Migraines: {context.migraines ? context.migraines.length : 0}</IonLabel></IonItem>
            { (context.migraines)
              ? context.migraines.map((m : Migraine) =>
                <IonItemSliding key={uuid.v4()}>
                  <IonItem><IonLabel className="ion-text-wrap">On {m.date} you had {m.description}.</IonLabel></IonItem>

                  <IonItemOptions side="end">
                    <IonItemOption color="danger" onClick={() => {
                      var i = context.migraines.findIndex(o => o.date === m.date && o.description === m.description);
                      if (i > -1) context.migraines.splice(i, 1);
                      saveMigraines(context.migraines);
                    }}>Delete</IonItemOption>
                  </IonItemOptions>
                </IonItemSliding>)
              : {} }
          </IonList>
        }
        </MigrainesContextConsumer>
      </IonContent>
    </IonPage>
  );
};

export default ListMigraines;
