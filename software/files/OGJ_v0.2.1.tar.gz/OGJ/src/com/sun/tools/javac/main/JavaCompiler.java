/**
 * @(#)JavaCompiler.java	1.53 03/07/17
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * WARNING! This class was modified to support OGJ extensions by
 * Alex Potanin (alex@mcs.vuw.ac.nz).
 */

package com.sun.tools.javac.main;

import java.io.*;
import java.util.Set;
import java.util.HashSet;

import com.sun.tools.javac.util.*;
import com.sun.tools.javac.code.*;
import com.sun.tools.javac.tree.*;
import com.sun.tools.javac.parser.*;
import com.sun.tools.javac.comp.*;
import com.sun.tools.javac.jvm.*;

import com.sun.tools.javac.code.Symbol.*;
import com.sun.tools.javac.tree.Tree.*;

/** This class could be the main entry point for GJC when GJC is used as a
 *  component in a larger software system. It provides operations to
 *  construct a new compiler, and to run a new compiler on a set of source
 *  files.
 *
 *  <p><b>This is NOT part of any API suppored by Sun Microsystems.  If
 *  you write code that depends on this, you do so at your own risk.
 *  This code and its internal interfaces are subject to change or
 *  deletion without notice.</b>
 */
public class JavaCompiler implements ClassReader.SourceCompleter {
    /** The current version number as a string.
     */
    public static String version() { return System.getProperty("java.version"); }

    /** The log to be used for error reporting.
     */
    private Log log;

    /** The tree factory module.
     */
    private TreeMaker make;

    /** The class reader.
     */
    private ClassReader reader;

    /** The class writer.
     */
    ClassWriter writer;

    /** The module for the symbol table entry phases.
     */
    private Enter enter;

    /** The symbol table.
     */
    Symtab syms;

    /** The language version.
     */
    Source source;

    /** The module for code generation.
     */
    Gen gen;

    /** The name table.
     */
    Name.Table names;

    /** The attributor.
     */
    Attr attr;

    /** The flow analyzer.
     */
    Flow flow;

    /** The type eraser.
     */
    TransTypes transTypes;

    /** The syntactic sugar desweetener.
     */
    Lower lower;

    /** Force a completion failure on this name
     */
    final Name completionFailureName;

    /** The context.
     */
    Context context;

    /** Construct a new compiler from a log, a symbol table and an options table.
     */
    public JavaCompiler(Context context) {
	this.context = context;
	names = Name.Table.instance(context);
	log = Log.instance(context);
	reader = ClassReader.instance(context);
	make = TreeMaker.instance(context);
	writer = ClassWriter.instance(context);
	enter = Enter.instance(context);
	todo = Todo.instance(context);
	syms = Symtab.instance(context);
	source = Source.instance(context);
	attr = Attr.instance(context);
	gen = Gen.instance(context);
	flow = Flow.instance(context);
	transTypes = TransTypes.instance(context);
	lower = Lower.instance(context);

	reader.sourceCompleter = this;

	Options options = Options.instance(context);

	verbose       = options.get("-verbose")       != null;
	sourceOutput  = options.get("-s")             != null;
	stubOutput    = options.get("-stubs")         != null;
	classOutput   = options.get("-retrofit")      == null;
	relax         = options.get("-relax")         != null;
	printFlat     = options.get("-printflat")     != null;
	deprecation   = options.get("-deprecation")   != null;
	warnunchecked = options.get("-warnunchecked") != null;
	attrParseOnly = options.get("-attrparseonly") != null;
	encoding      = options.get("-encoding");
	genCrt = options.get("-Xjcov") != null;
	Type.debugSubTyping = options.get("-debugsubtyping") != null;

	completionFailureName = 
	    (options.get("failcomplete") != null)
	    ? names.fromString(options.get("failcomplete"))
	    : null;
    }

    /** Construct a new compiler.
     *  This will create a new symbol table module.
     */
    public static JavaCompiler make(Context context) {
	try {
	    // force creation of the symbol table to 
	    // catch completion problems with predefineds
	    Symtab.instance(context);
	} catch (CompletionFailure ex) {
	    Log log = Log.instance(context);
	    log.error(Position.NOPOS, ex.getMessage());
	    return null;
	}
	return new JavaCompiler(context);
    }

    /* Switches:
     */

    /** Verbose output.
     */
    public boolean verbose;

    /** Emit plain Java source files rather than class files.
     */
    public boolean sourceOutput;

    /** Emit stub source files rather than class files.
     */
    public boolean stubOutput;

    /** Generate attributed parse tree only.
     */
    public boolean attrParseOnly;

    /** Emit class files. This switch is always set, except for the first
     *  phase of retrofitting, where signatures are parsed.
     */
    public boolean classOutput;

    /** Switch: relax some constraints for retrofit mode.
     */
    boolean relax;

    /** Debug switch: Emit Java sources after inner class flattening.
     */
    public boolean printFlat;

    /** Give detailed deprecation warnings.
     */
    public boolean deprecation;

    /** Give detailed unchecked and unsafe warnings.
     */
    public boolean warnunchecked;

    /** Generate the CharacterRangeTable.
     */
    public boolean genCrt;
   
    /** The encoding to be used for source input.
     */
    public String encoding;

    /** A queue of all as yet unattributed classes.
     */
    private Todo todo;

    /** The set of currently compiled inputfiles, needed to ensure
     *  we don't accidentally overwrite an input file when -s is set.
     *  initialized by `compile'.
     */
    Set<File> inputFiles = new HashSet<File>();

    /** The number of errors reported so far.
     */
    public int errorCount() {
	return log.nerrors;
    }

    /** The number of errors reported so far.
     */
    public int warningCount() {
	return log.nwarnings;
    }

    /** Try to open input stream with given name.
     *  Report an error if this fails.
     *  @param filename   The file name of the input stream to be opened.
     */
    public InputStream openSource(String filename) {
        try {
	    File f = new File(filename);
	    inputFiles.add(f);
	    return new FileInputStream(f);
        } catch (IOException e) {
	    log.error(Position.NOPOS, "cant.read.file", filename);
            return null;
        }
    }

    /** Parse contents of input stream.
     *  @param filename     The name of the file from which input stream comes.
     *  @param input        The input stream to be parsed.
     */
    public TopLevel parse(String filename, InputStream input) {
        long msec = System.currentTimeMillis();
	Name prev = log.useSource(names.fromString(filename));
	TopLevel tree = make.TopLevel(null, Tree.emptyList);
        if (input != null) {
            if (verbose) {
		printVerbose("parsing.started", filename);
            }
	    try {
		Scanner scanner = new Scanner(context, input, encoding);
		input.close();
		Parser parser = new Parser(context, scanner, keepComments(), genCrt);
		tree = parser.compilationUnit();
		if (verbose) {
		    printVerbose("parsing.done",
				 Long.toString(System.currentTimeMillis() - msec));
		}
	    }  catch (IOException e) {
		log.error(Position.NOPOS,
			  "error.reading.file", filename, e);
	    }
	}
	log.useSource(prev);
	tree.sourcefile = names.fromString(filename);
	return tree;
    }
    // where
	protected boolean keepComments() {
	    return sourceOutput;
	}


    /** Parse contents of file.
     *  @param filename     The name of the file to be parsed.
     */
    public Tree.TopLevel parse(String filename) {
        return parse(filename, openSource(filename));
    }

    /** Emit plain Java source for a class.
     *  @param env    The attribution environment of the outermost class
     *                containing this class.
     *  @param cdef   The class definition to be printed.
     */
    void printSource(Env<AttrContext> env, ClassDef cdef) throws IOException {
	File outFile = writer.outputFile(cdef.sym, ".java");
	if (inputFiles.contains(outFile)) {
	    log.error(cdef.pos, "source.cant.overwrite.input.file", outFile);
	} else {
	    PrintWriter out = new PrintWriter
		(new BufferedWriter
		    (new OutputStreamWriter
			(new FileOutputStream(outFile))));
	    try {
		new Pretty(out, true).printUnit(env.toplevel, cdef);
		if (verbose)
		    printVerbose("wrote.file", outFile.getPath());
	    } finally {
		out.close();
	    }
	}
    }

    /** Generate code and emit a class file for a given class
     *  @param env    The attribution environment of the outermost class
     *                containing this class.
     *  @param cdef   The class definition from which code is generated.
     */
    void genCode(Env<AttrContext> env, ClassDef cdef) throws IOException {
	try {
	    if (gen.genClass(env, cdef)) writer.writeClass(cdef.sym);
	} catch (ClassWriter.PoolOverflow ex) {
	    log.error(cdef.pos, "limit.pool");
	} catch (ClassWriter.StringOverflow ex) {
	    log.error(cdef.pos, "limit.string.overflow",
		      ex.value.substring(0, 20));
	} catch (CompletionFailure ex) {
	    log.error(Position.NOPOS, ex.getMessage());
	}
    }

    /** Complete compiling a source file that has been accessed
     *  by the class file reader.
     *  @param c          The class the source file of which needs to be compiled.
     *  @param filename   The name of the source file.
     *  @param f          An input stream that reads the source file.
     */
    public void complete(ClassSymbol c,
			 String filename,
			 InputStream f) throws CompletionFailure {
//      System.err.println("completing " + c);//DEBUG
	if (completionFailureName == c.fullname) {
	    throw new CompletionFailure(c, "user-selected completion failure by class name");
	}
	Tree tree = parse(filename, f);
	enter.complete(List.make(tree), c);
	if (enter.getEnv(c) == null) {
	    throw new 
		ClassReader.BadClassFile(c, filename, log.
					 getLocalizedString("file.doesnt.contain.class",
							    c.fullname));
	}
    }
    
    /** Track when the JavaCompiler has been used to compile something. */
    private boolean hasBeenUsed = false;

    /**
     * The following fields define constants used by OGJ extensions.
     */
    public static String ogjPackageName = "ogj.ownership";
    public static String ogjPrefixPseudo = "OHGEEJAVAPREFIX";
    public static String ogjPrefixPackage = ogjPrefixPseudo + "PACKAGE";
    public static String ogjPrefixStatic = ogjPrefixPseudo + "STATIC";
    public static String ogjPrefixPrivate = ogjPrefixPseudo + "PRIVATE";
    public static String ogjDefaultPackageName = "DefaultPackage";
    public static String ogjDotReplacement = "DOT";
    public static String ogjNameWorld = "World";
    public static String ogjNamePackage = "Package";
    public static String ogjNameStatic = "Static";	
    public static String ogjNamePrivate = "Private";

    /**
     * This method will replace all occurences of
     * ogj.ownership.Package, ogj.ownership.Static, and
     * ogj.ownership.Private with appropriate special classes.
     */
    private List<Tree> replaceOGJKeywords(List<Tree> roots) {
	ListBuffer<String> pseudoClassesThatNeedCreation = new ListBuffer<String>();
	ListBuffer<Tree> newroots = new ListBuffer<Tree>();

	// The following will be initialised based on the code that I
	// will see.
	Name.Table table = null;
	
	while (roots.nonEmpty()) {
	    TopLevel tree = (TopLevel) roots.head;

	    // Initialise the table with appropriate reference.
	    if (table == null)
		table = tree.sourcefile.table;

	    String packageName;
	    if (tree.pid == null) {
		// Default package.
		packageName = JavaCompiler.ogjDefaultPackageName;
	    } else {
		// Some named package.
		packageName = replacePackageDots(tree.pid.toString());
	    }
	    packageName = JavaCompiler.ogjPrefixPackage + packageName;

	    List<Tree> defs =  tree.defs;
	    ListBuffer<Tree> newdefs = new ListBuffer<Tree>();
	    
	    while (defs.nonEmpty()) {
		if (defs.head.tag == Tree.CLASSDEF) {
		    ClassDef cdef = (ClassDef) defs.head;

		    String staticName = packageName + cdef.name.toString();
		    String privateName = JavaCompiler.ogjPrefixPrivate + staticName;
		    staticName = JavaCompiler.ogjPrefixStatic + staticName;

		    OGJKeywordsReplacer kr = new OGJKeywordsReplacer(packageName, staticName, privateName);

		    if (!pseudoClassesThatNeedCreation.toList().contains(staticName)) {
			pseudoClassesThatNeedCreation.append(staticName);
		    }

		    if (!pseudoClassesThatNeedCreation.toList().contains(privateName)) {
			pseudoClassesThatNeedCreation.append(privateName);
		    }

		    newdefs.append(kr.translate(defs.head));
		} else {
		    newdefs.append(defs.head);
		}

		defs = defs.tail;
	    }

	    if (!pseudoClassesThatNeedCreation.toList().contains(packageName)) {
		pseudoClassesThatNeedCreation.append(packageName);
	    }

	    tree.defs = newdefs.toList();

	    roots = roots.tail;
	    newroots.append(tree);
	}

	if (pseudoClassesThatNeedCreation.toList().nonEmpty()) {
	    // Create pseudo classes in ogj.ownership package.
	    Tree pid = new Select(new Ident(Name.fromString(table, "ogj"), null),
				  Name.fromString(table, "ownership"), null);	

	    if (!JavaCompiler.ogjPackageName.equals("ogj.ownership")) {
		System.out.println("OGJ ERROR: JavaCompiler.ogjPackageName is no longer ogj.ownership " +
				   "but it is HARD CODED in JavaCompiler.replaceOGJKeywords method.");
	    }

	    Tree ogjOwnershipWorld = new Ident(Name.fromString(table, JavaCompiler.ogjNameWorld), null);
	    ListBuffer<Tree> implementingBuffer = new ListBuffer<Tree>();
	    implementingBuffer.append(ogjOwnershipWorld);
	    List<Tree> implementing = implementingBuffer.toList();
	    
	    List<String> names = pseudoClassesThatNeedCreation.toList();
	    while (names.nonEmpty()) {
		ListBuffer<Tree> defs = new ListBuffer<Tree>();

		// Add a pseudo class to the current package.
		ClassDef pseudoclass = new ClassDef(Flags.INTERFACE | Flags.PUBLIC,
						    Name.fromString(table, names.head),
						    TypeParameter.emptyList,
						    null,
						    implementing,
						    Tree.emptyList,
						    null);
		
		defs.append(pseudoclass);
	    
		// Add ClassDefs for pseudoclasses.
		Tree.TopLevel toplevel = new TopLevel(pid,
						      defs.toList(),
						      Name.fromString(table, names.head + ".java"),
						      null,
						      null,
						      null);
		
		// Add a new top level variable representing the pseudo classes for packages.
		newroots.append(toplevel);
		
		names = names.tail;
	    }
	}

	return newroots.toList();
    }
    // where
    private String replacePackageDots(String packageName) {
	String result = "";
	int i = 0;
	int prevI = 0;
	while (packageName.indexOf(".", prevI) != -1) {
	    i = packageName.indexOf(".", prevI);
	    result += packageName.substring(prevI, i) + JavaCompiler.ogjDotReplacement;
	    prevI = i + 1;
	}
	result += packageName.substring(prevI, packageName.length());
	return result;
    }
    // where
    class OGJKeywordsReplacer extends TreeTranslator {
	private String pseudoClassPackage;
	private String pseudoClassStatic;
	private String pseudoClassPrivate;
	public OGJKeywordsReplacer(String pseudoClassPackage,
				   String pseudoClassStatic,
				   String pseudoClassPrivate) {
	    this.pseudoClassPackage = pseudoClassPackage;
	    this.pseudoClassStatic = pseudoClassStatic;
	    this.pseudoClassPrivate = pseudoClassPrivate;
	}
	public void visitTypeApply(TypeApply t) {
	    ListBuffer<Tree> newargs = new ListBuffer<Tree>();
	    while (t.arguments.nonEmpty()) {
		Tree arg = t.arguments.head;
		
		if (arg.toString().equals(JavaCompiler.ogjPackageName + "." +
					  JavaCompiler.ogjNamePackage)) {
		    Select sel = (Select) arg;
		    sel.name = Name.fromString(sel.name.table, pseudoClassPackage);
		} else if (arg.toString().equals(JavaCompiler.ogjPackageName + "." +
						 JavaCompiler.ogjNameStatic)) {
		    Select sel = (Select) arg;
		    sel.name = Name.fromString(sel.name.table, pseudoClassStatic);
		} else if (arg.toString().equals(JavaCompiler.ogjPackageName + "." +
						 JavaCompiler.ogjNamePrivate)) {
		    Select sel = (Select) arg;
		    sel.name = Name.fromString(sel.name.table, pseudoClassPrivate);
		}

		t.arguments = t.arguments.tail;
		newargs.append(arg);
	    }
	    t.arguments = newargs.toList();
	    super.visitTypeApply(t);
	}
    }

    private Tree checkOGJPrivate(Tree tree) {
	OGJPrivateValidator pv = new OGJPrivateValidator();	    
	return pv.translate(tree);
    }
    // where
    class OGJPrivateValidator extends TreeTranslator {
	public OGJPrivateValidator() {
	}
	public void visitApply(Apply a) {
	    Symbol.MethodSymbol ms = null;
	    if (a.meth.tag == Tree.IDENT) {
		ms = (Symbol.MethodSymbol) ((Ident) a.meth).sym;
		// System.out.println("Method (Ident): " + ms);
	    } else if (a.meth.tag == Tree.SELECT) {
		ms = (Symbol.MethodSymbol) ((Select) a.meth).sym;
		// System.out.println("Method (Select): " + ms);
	    } else {
		System.out.println("OGJ Warning: Unknown method kind in " +
				   "OGJPrivateValidator.visitApply().");
	    }

	    // Examine method symbol in detail.
	    // System.out.println("Method's type: " + ms.type);
	    // System.out.println("Method's owner: " + ms.owner);
	    // System.out.println("Enclosing class: " + ms.enclClass());

	    // If the method's return type contains
	    // ogj.ownership.Private ownership parameter anywhere in
	    // its type, then we are only allowed to execute this
	    // method upon this.
	    if (ms.type.asMethodType().restype.hasPrivateOwnerParameter()) {
		if (a.meth.tag == Tree.IDENT) {
		    // This is implicit this. Hence it is OK.
		} else if (a.toString().startsWith("this.")) {
		    // This is explicit this. Hence it is OK.
		} else {
		    // This is NOT OK to call something that returns
		    // ogj.ownership.Private and we are not calling it
		    // on the actual this instance.
		    System.out.println("OGJ Error: Illegal method call that returns a result " +
				       "parameterised by " + JavaCompiler.ogjPackageName + "." +
				       JavaCompiler.ogjNamePrivate);
		    log.error(a.pos, "compiler.err.cant.deref");
		}
	    }
	    super.visitApply(a);
	}
	public void visitSelect(Select s) {
	    if (s.sym instanceof Symbol.VarSymbol) {
		Symbol.VarSymbol vs = (Symbol.VarSymbol) s.sym;

		// Examine variable symbol in detail.
		// System.out.println("Visiting (Select): " + s);
		// System.out.println("Symbol (Select): " + s.sym + " and class: " + s.sym.getClass());
		// System.out.println("Type (Select): " + vs.type + " and class: " + vs.type.getClass());

		if (vs.type.hasPrivateOwnerParameter()) {
		    if (s.toString().startsWith("this.")) {
			// This is implicit this. Hence it is OK.
		    } else {
			// This is NOT OK to call something that has a
			// type ogj.ownership.Private and we are not
			// accessing it on the actual this instance.
			System.out.println("OGJ Error: Illegal field access that returns a result " +
					   "parameterised by " + JavaCompiler.ogjPackageName + "." +
					   JavaCompiler.ogjNamePrivate);
			log.error(s.pos, "compiler.err.cant.deref");
		    }
		}
	    }
	    super.visitSelect(s);
	}
	// Note that Ident means that field has implicit this, hence OK for us. :-)
	public void visitIdent(Ident i) {
	    super.visitIdent(i);
	}
	public void visitVarDef(VarDef vd) {
	    super.visitVarDef(vd);
	}
	public void visitAssign(Assign a) {
	    super.visitAssign(a);
	}
	public void visitNewClass(NewClass nc) {
	    super.visitNewClass(nc);
	}
    }

    /** Main method: compile a list of files, return all compiled classes
     *  @param filenames     The names of all files to be compiled.
     *
     *  OGJ modifications follow to insert a special traversal of the
     *  trees with the source (right after parsing) to replace special
     *  class names denoting current package or current class
     *  confinements. This way, we can avoid using keywords for now.
     */
    public List<ClassSymbol> compile(List<String> filenames) throws Throwable {
	// as a JavaCompiler can only be used once, throw an exception if
	// it has been used before.
	assert !hasBeenUsed : "attempt to reuse JavaCompiler";
	hasBeenUsed = true;

	long msec = System.currentTimeMillis();
	ListBuffer<ClassSymbol> classes = new ListBuffer<ClassSymbol>();
	try {
	    //parse all files
	    ListBuffer<Tree> trees = new ListBuffer<Tree>();
	    for (List<String> l = filenames; l.nonEmpty(); l = l.tail)
		trees.append(parse(l.head));

            List<Tree> roots = trees.toList();

	    // OGJ: Now that we parsed all the files, lets make small
	    // adjustments.
	    roots = replaceOGJKeywords(roots);

            //enter symbols for all files
            if (errorCount() == 0) enter.main(roots);

            //If generating source, remember the classes declared in
            //the original compilation units listed on the command line.
            List<ClassDef> rootClasses = null;
            if (sourceOutput || stubOutput) {
                ListBuffer<ClassDef> cdefs = new ListBuffer <ClassDef>();
                for (List<Tree> l = roots; l.nonEmpty(); l = l.tail) {
                    for (List<Tree> defs = ((TopLevel)l.head).defs;
			 defs.nonEmpty();
			 defs = defs.tail) {
                        if (defs.head instanceof ClassDef)
                            cdefs.append((ClassDef)defs.head);
                    }
                }
                rootClasses = cdefs.toList();
            }

	    while (todo.nonEmpty()) {
		Env<AttrContext> env = todo.next();

		//save tree prior to rewriting
                Tree untranslated = env.tree;

		//attribution phase
		if (verbose)
		    printVerbose("checking.attribution", env.enclClass.sym);
		Name prev = log.useSource(env.enclClass.sym.sourcefile);
		attr.attribClass(env.tree.pos, env.enclClass.sym);
		if (attrParseOnly) continue;

		make.at(Position.FIRSTPOS);
		TreeMaker localMake = new TreeMaker(env.toplevel);

		//dataflow checks: definite assignments, unreachable statements
		if (errorCount() == 0  && !relax) {
		    flow.analyzeTree(env.tree, localMake);
		}

		ClassDef cdef = null;
		try {
		    if (errorCount() == 0) {
			if (stubOutput) {
                            //emit stub Java source file, only for compilation
                            //units enumerated explicitly on the command line
			    cdef = (ClassDef)env.tree;
                            if (untranslated instanceof ClassDef && 
				rootClasses.contains((ClassDef)untranslated) &&
				((cdef.flags & (Flags.PROTECTED|Flags.PUBLIC)) != 0 ||
				 cdef.sym.packge().fullName() == names.java_lang)) {
                                printSource(env, removeMethodBodies(cdef));
                            }
			    continue;
			}

			// Ignore the classes we faked.
			cdef = (ClassDef) env.tree;
			if (cdef.name.toString().startsWith("OHGEEJAVA")) {
			    continue;
			}

			// OGJ change: Check for proper uses of
			// ogj.ownership.Private.
			env.tree = checkOGJPrivate(cdef);
			
			env.tree = transTypes.translateTopLevelClass(env.tree, localMake);

			if (errorCount() != 0) continue;

			if (sourceOutput) {
                            //emit standard Java source file, only for compilation
                            //units enumerated explicitly on the command line
			    cdef = (ClassDef)env.tree;
                            if (untranslated instanceof ClassDef && 
				rootClasses.contains((ClassDef)untranslated)) {
                                printSource(env, cdef);
                            }
			    continue;
			}

			//translate out inner classes
			List<Tree> cdefs = lower
			    .translateTopLevelClass(env, env.tree, localMake);

			//generate code for each class
			if (errorCount() != 0) continue;
			for (List<Tree> l = cdefs;
			     errorCount() == 0 && l.nonEmpty();
			     l = l.tail) {
			    cdef = (ClassDef)l.head;
			    if (printFlat) 
				printSource(env, cdef);
			    else if (classOutput)
				genCode(env, cdef);
			    classes.append(cdef.sym);
			}
		    }
		} catch (IOException ex) {
		    log.error(cdef.pos, "class.cant.write",
			      cdef.sym, ex.getMessage());
		} finally {
		    log.useSource(prev);
		}
	    }
	} catch (Abort ex) {
	}

	Check chk = Check.instance(context);
	if (verbose)
	    printVerbose("total", Long.toString(System.currentTimeMillis() - msec));
	if (chk.deprecatedSource != null && !deprecation)
	    noteDeprecated(chk.deprecatedSource);
	if (chk.uncheckedSource != null && !warnunchecked)
	    makeNotes(chk.uncheckedSource.toString());

	int errCount = errorCount();
	if (errCount == 1)
	    printCount("error", errCount);
	else
	    printCount("error.plural", errCount);

	if (log.nwarnings == 1)
	    printCount("warn", log.nwarnings);
	else
	    printCount("warn.plural", log.nwarnings);

	return classes.toList();
    }
    // where
    ClassDef removeMethodBodies(ClassDef cdef) {
	    final boolean isInterface = (cdef.flags & Flags.INTERFACE) != 0;
	    class MethodBodyRemover extends TreeTranslator {
		public void visitMethodDef(MethodDef tree) {
		    tree.flags &= ~Flags.SYNCHRONIZED;
		    for (VarDef vd : tree.params)
			vd.flags &= ~Flags.FINAL;
		    tree.body = null;
		    super.visitMethodDef(tree);
		}
		public void visitVarDef(VarDef tree) {
		    if (tree.init != null && tree.init.type.constValue == null)
			tree.init = null;
		    super.visitVarDef(tree);
		}
		public void visitClassDef(ClassDef tree) {
		    ListBuffer<Tree> newdefs = new ListBuffer<Tree>();
		    for (List<Tree> it = tree.defs; it.tail != null; it = it.tail) {
			Tree t = it.head;
			switch (t.tag) {
			case Tree.CLASSDEF:
			    if (isInterface ||
				(((ClassDef)t).flags & (Flags.PROTECTED|Flags.PUBLIC)) != 0 ||
				(((ClassDef)t).flags & (Flags.PRIVATE)) == 0 && ((ClassDef)t).sym.packge().fullName() == names.java_lang)
				newdefs.append(t);
			    break;
			case Tree.METHODDEF:
			    if (isInterface ||
				(((MethodDef)t).flags & (Flags.PROTECTED|Flags.PUBLIC)) != 0 ||
				((MethodDef)t).sym.name == names.init ||
				(((MethodDef)t).flags & (Flags.PRIVATE)) == 0 && ((MethodDef)t).sym.packge().fullName() == names.java_lang)
				newdefs.append(t);
			    break;
			case Tree.VARDEF:
			    if (isInterface || (((VarDef)t).flags & (Flags.PROTECTED|Flags.PUBLIC)) != 0 ||
				(((VarDef)t).flags & (Flags.PRIVATE)) == 0 && ((VarDef)t).sym.packge().fullName() == names.java_lang)
				newdefs.append(t);
			    break;
			default:
			    break;
			}
		    }
		    tree.defs = newdefs.toList();
		    super.visitClassDef(tree);
		}
	    }
	    MethodBodyRemover r = new MethodBodyRemover();
	    return (ClassDef)r.translate(cdef);
	}

    /** Close the compiler, flushing the logs
     */
    public void close() {
	log.flush();
	reader.close();
	names.dispose();
    }

    /** Output for "-verbose" option.
     *  @param key The key to look up the correct internationalized string.
     *  @param arg An argument for substitution into the output string.
     */
    private void printVerbose(String key, Object arg) {
	Log.printLines(log.noticeWriter, log.getLocalizedString("verbose." + key, arg));
    }

    /** Print note that deprecated API's are used.
     */
    private void noteDeprecated(Object input) {
	if (input.equals("*"))
	    log.note("deprecated.plural");
	else
	    log.note("deprecated.filename", input);
	log.note("deprecated.recompile");
    }

    /** Print note that unchecked or unsafe operations are used.
     */
    void makeNotes(Object input) {
	if (input.toString().equals("*"))
	    log.note("unchecked.plural");
	else
	    log.note("unchecked.filename", input);
	log.note("unchecked.recompile");
    }

    /** Print numbers of errors and warnings.
     */
    void printCount(String kind, int count) {
        if (count != 0) {
	    Log.printLines(log.errWriter,
			   log.getLocalizedString("count." + kind,
						  Integer.toString(count)));
	    log.errWriter.flush();
	}
    }
}
