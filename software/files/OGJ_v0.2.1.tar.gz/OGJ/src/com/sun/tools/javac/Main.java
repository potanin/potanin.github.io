/**
 * @(#)Main.java	1.17 03/01/27
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * WARNING! This class was modified to support OGJ extensions by
 * Alex Potanin (alex@mcs.vuw.ac.nz).
 */

package com.sun.tools.javac;

import java.io.PrintWriter;

/**
 * The main program for the command-line compiler javac.
 *
 * <p>Nothing described in this source file is part of any supported
 * API.  If you write code that depends on this, you do so at your own
 * risk.  This code and its internal interfaces are subject to change
 * or deletion without notice.
 */
public class Main {

    static {
	ClassLoader loader = Main.class.getClassLoader();
	if (loader != null) 
	    loader.setPackageAssertionStatus("com.sun.tools.javac", true);
    }

    /** Command line interface.
     * @param args   The command line parameters.
     */
    public static void main(String[] args) {
	System.out.println("Oh! Gee! Java! extension to javac by Alex Potanin " +
			   "(alex@mcs.vuw.ac.nz) version 0.2.1");
	System.exit(compile(args));
    }

    /** Programmatic interface.
     * @param args   The command line parameters.
     */
    public static int compile(String[] args) {
	com.sun.tools.javac.main.Main compiler =
	    new com.sun.tools.javac.main.Main("javac");
	return compiler.compile(args);
    }

    /** Programmatic interface.
     * @param args   The command line parameters.
     * @param out    Where the compiler's output is directed.
     */
    public static int compile(String[] args, PrintWriter out) {
	com.sun.tools.javac.main.Main compiler =
	    new com.sun.tools.javac.main.Main("javac", out);
	return compiler.compile(args);
    }
}
