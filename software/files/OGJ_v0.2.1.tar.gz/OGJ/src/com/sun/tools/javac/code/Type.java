/**
 * @(#)Type.java	1.65 03/07/15
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * WARNING! This class was modified to support OGJ extensions by
 * Alex Potanin (alex@mcs.vuw.ac.nz).
 */

package com.sun.tools.javac.code;

import com.sun.tools.javac.util.*;
import com.sun.tools.javac.code.Symbol.*;

import static com.sun.tools.javac.code.Flags.*;
import static com.sun.tools.javac.code.Kinds.*;
import static com.sun.tools.javac.code.BoundKind.*;
import static com.sun.tools.javac.code.TypeTags.*;

/** This class represents GJ types. The class itself defines the behavior of
 *  the following types:
 *  <pre>
 *  base types (tags: BYTE, CHAR, SHORT, INT, LONG, FLOAT, DOUBLE, BOOLEAN),
 *  type `void' (tag: VOID),
 *  the bottom type (tag: BOT),
 *  the missing type (tag: NONE).
 *  </pre>
 *  <p>The behavior of the following types is defined in subclasses, which are
 *  all static inner classes of this class:
 *  <pre>
 *  class types (tag: CLASS, class: ClassType),
 *  array types (tag: ARRAY, class: ArrayType),
 *  method types (tag: METHOD, class: MethodType),
 *  package types (tag: PACKAGE, class: PackageType),
 *  type variables (tag: TYPEVAR, class: TypeVar),
 *  type arguments (tag: TYPEARG, class: ArgumentType),
 *  polymorphic types (tag: FORALL, class: ForAll),
 *  the error type (tag: ERROR, class: ErrorType).
 *  </pre>
 *
 *  <p><b>This is NOT part of any API suppored by Sun Microsystems.  If
 *  you write code that depends on this, you do so at your own risk.
 *  This code and its internal interfaces are subject to change or
 *  deletion without notice.</b>
 *
 *  @see TypeTags
 */
public class Type {

   /** Constant type: no type at all. */
    public static final Type noType = new Type(NONE, null);

    /** If this switch is turned on, the names of type variables
     *  and anonymous classes are printed with hashcodes appended.
     */
    public static boolean moreInfo = false;
    public static boolean debugSubTyping = false;

    /** The tag of this type.
     *
     *  @see TypeTags
     */
    public int tag;

    /** The defining class / interface / package / type variable
     */
    public TypeSymbol tsym;

    /** The constant value of this type, null if this type does not have
     *  a constant value attribute. Constant values can be set only for
     *  base types (numbers, booleans) and class types (strings).
     */
    public Object constValue = null;

    public void accept(Visitor v) { v.visitType(this); }

    /** Define a type given its tag and type symbol
     */
    public Type(int tag, TypeSymbol tsym) {
	this.tag = tag;
	this.tsym = tsym;
    }

    /** The rank of a class is the length of the longest path
     *  between the class and java.lang.Object in the class inheritance
     *  graph. Undefined for all but reference types.
     */
    public int rank() {
	throw new AssertionError();
    }

    // Returns the lower bounds of the formals of a method.
    public List<Type> lowerBoundArgtypes() {
	return argtypes();
    }

    // These functions are the predicates that are used in deciding
    // whether to report an array assign warning. No types but arrays
    // can return true, "safe == !unsafe" is not true.
    public boolean isUnsafe() { return false; }
    public boolean isSafe() { return false; }

    public boolean isReifiable() { return true; }

    public boolean isArray() {
        return false;
    }

    // Are all subtypes reifiable
    public boolean areSubsReifiable() { return false; }

    // Represent as a type argument
    public Type normalize() { 
	Type thisStripped = simplifyArgumentType();
	if (thisStripped.tag == TYPEARG) {
	    return thisStripped;
	} else {
	    return new ArgumentType(thisStripped,
				    EXACT,
				    null,
				    null);
	}
    }
    
    // Are all supertypes (including the type itself) reifiable
    public boolean areSupersReifiable() { return isReifiable(); }

    /** An abstract class for mappings from types to types
     */
    public static abstract class Mapping {
	public abstract Type apply(Type t);
    }

    /** map a type function over all immediate descendants of this type
     */
    public Type map(Mapping f) {
	return this;
    }

    /** map a type function over a list of types
     */
    public static List<Type> map(List<Type> these, Mapping f) {
	if (these.nonEmpty()) {
	    List<Type> tail1 = map(these.tail, f);
	    Type head1 = f.apply(these.head);
	    if (tail1 != these.tail || head1 != these.head)
		return tail1.prepend(head1);
	}
	return these;
    }

    /** Define a constant type, of the same kind as this type
     *  and with given constant value
     */
    public Type constType(Object constValue) {
	assert tag <= BOOLEAN;
	Type t = new Type(tag, tsym);
	t.constValue = constValue;
	return t;
    }

    /** If this is a constant type, return its underlying type.
     *  Otherwise, return the type itself.
     */
    public Type baseType() {
	if (constValue == null) return this;
	else return tsym.type;
    }

    /** Return the base types of a list of types.
     */
    public static List<Type> baseTypes(List<Type> types) {
	if (types.nonEmpty()) {
	    Type t = types.head.baseType();
	    List<Type> ts = baseTypes(types.tail);
	    if (t != types.head || ts != types.tail)
		return new List<Type>(t, ts);
	}
	return types;
    }

    /** The Java source which this type represents.
     */
    public String toString() {
	String s = (tsym == null || tsym.name == null)
	    ? "null"
	    : tsym.name.toString();
	if (moreInfo && tag == TYPEVAR) s = s + hashCode();
	return s;
    }

    /** The Java source which this type list represents.  A List is
     *  represented as a comma-spearated listing of the elements in
     *  that list.
     */
    public static String toString(List<Type> list) {
	if (list.isEmpty()) {
	    return "";
	} else {
	    StringBuffer buf = new StringBuffer();
	    buf.append(list.head.toString());
	    for (List<Type> l = list.tail; l.nonEmpty(); l = l.tail)
		buf.append(",").append(l.head.toString());
	    return buf.toString();
	}
    }

    /** The constant value of this type, converted to String
     *  PRE: Type has a non-null constValue field.
     */
    public String stringValue() {
	if (tag == BOOLEAN)
	    return ((Integer) constValue).intValue() == 0 ? "false" : "true";
	else if (tag == CHAR)
	    return String.valueOf((char) ((Integer) constValue).intValue());
	else
	    return constValue.toString();
    }

    /** This method is analogous to isSameType, but weaker, since we 
     *  never complete classes. Where isSameType would complete a class,
     *  equals assumes that the two types are different. 
     *  The code of this method is commented out since it is redundant.
     *  But it will be overridden in subclasses.
     */
//  public boolean equals(Object that) {
//      return super.equals(that);
//  }

    /** The code of this method is commented out since it is redundant.
     *  But it will be overridden in subclasses.
     */
//  public int hashCode() {
//	return super.hashCode();
//  }

    /** Is this a constant type whose value is false?
     */
    public boolean isFalse() {
	return
	    tag == BOOLEAN &&
	    constValue != null &&
	    ((Integer)constValue).intValue() == 0;
    }

    /** Is this a constant type whose value is true?
     */
    public boolean isTrue() {
	return
	    tag == BOOLEAN &&
	    constValue != null &&
	    ((Integer)constValue).intValue() != 0;
    }

    /** Access methods.
     */
    public List<Type>	     typarams() { return emptyList; }
    public Type		     outer()	{ return null; }
    public Type		     elemtype() { return null; }
    public int		     dimensions() { return 0; }
    public List<Type>	     argtypes() { return emptyList; }
    public Type		     restype()	{ return null; }
    public List<Type>	     thrown()	{ return Type.emptyList; }
    public Type		     bound()	{ return null; }

    public void setThrown(List<Type> t) {
	throw new AssertionError();
    }

    /** Navigation methods, these will work for classes, type variables,
     *  foralls, but will return null for arrays and methods.
     */
    // FIXME(VFORCE): we may not know how to deliver "the" supertype of this type
    public Type supertype()        { return null; }
    public List<Type> interfaces() { return emptyList; }

   /** Return all parameters of this type and all its outer types in order
    *  outer (first) to inner (last).
    */
    public List<Type> allparams() { return emptyList; }

    /** Return the (most specific) base type of this type that starts
     *  with symbol sym.  If none exists, return null.
     */
    public Type asSuper(Symbol sym) { return null; }

    /** Return the base type of this type or any
     *  of its outer types that starts with symbol sym.
     *  If none exists, return null.
     */
    public Type asOuterSuper(Symbol sym) { return null; }

    /** If this type is a (possibly selected) type variable,
     *  return the bounding class of this type, otherwise
     *  return the type itself
     */
    public Type classBound() { return this; }

    /** Return the least specific subtype of this type that starts
     *  with symbol sym. if none exists, return null.
     *  The least specific subtype is determined as follows:
     *
     *  If there is exactly one parameterized instance of sym
     *  that is a subtype of this type, that parameterized instance is returned.
     *  Otherwise, if the plain type or raw type `sym' is a subtype
     *  of this type, the type `sym' itself is returned.
     *  Otherwise, null is returned.
     */
    Type asSub(Symbol sym) { return null; }

    /** The type of given symbol, seen as a member of this type
     */
    public Type memberType(Symbol sym) { return sym.type; }

    /** Substitute all occurrences of a type in `from' with the
     *  corresponding type in `to'. Match lists `from' and `to' from the right:
     *  If lists have different length, discard leading elements of the longer list.
     */
    public Type subst(List<Type> from, List<Type> to) {
	return this;
    }

    public static List<Type> subst(List<Type> these,
				   List<Type> from, List<Type> to) {
	if (these.tail != null /*inlined these.nonEmpty()*/ &&
            from.tail != null /*inlined from.nonEmpty()*/) {
	    Type head1 = these.head.subst(from, to);
	    List<Type> tail1 = subst(these.tail, from, to);
	    if (head1 != these.head || tail1 != these.tail)
		return tail1.prepend(head1);
	}
	return these;
    }

    /** Does this type contain "error" elements?
     */
    public boolean isErroneous() {
	return false;
    }

    public static boolean isErroneous(List<Type> ts) {
	for (List<Type> l = ts; l.nonEmpty(); l = l.tail)
	    if (l.head.isErroneous()) return true;
	return false;
    }

    /** Is this type parameterized?
     *  A class type is parameterized if it has some parameters.
     *  An array type is parameterized if its element type is parameterized.
     *  All other types are not parameterized.
     */
    public boolean isParameterized() {
	return false;
    }

    /** Is this type a raw type?
     *  A class type is a raw type if it misses some of its parameters.
     *  An array type is a raw type if its element type is raw.
     *  All other types are not raw.
     *  Type validation will ensure that the only raw types
     *  in a program are types that miss all their type variables.
     */
    public boolean isRaw() {
	return false;
    }

    public static boolean isRaw(List<Type> ts) {
	List<Type> l = ts;
	while (l.nonEmpty() && !l.head.isRaw()) l = l.tail;
	return l.nonEmpty();
    }

    public static boolean isDerivedRaw(Type t) {
	return
	    t.isRaw() || 
	    t.supertype() != null && isDerivedRaw(t.supertype()) || 
	    isDerivedRaw(t.interfaces());
    }

    public static boolean isDerivedRaw(List<Type> ts) {
	List<Type> l = ts;
	while (l.nonEmpty() && !isDerivedRaw(l.head)) l = l.tail;
	return l.nonEmpty();
    }

    public static boolean isExact(List<Type> ts) {
	List<Type> l = ts;
	while (l.nonEmpty() && l.head.isExact()) l = l.tail;
	return l.isEmpty();
    }

    public boolean isCompound() {
	return (tsym.flags() & COMPOUND) != 0;
    }

    public boolean isPrimitive() {
	return tag < VOID;
    }

    /** The erasure of this type -- the type that results when
     *  all type parameters in this type are deleted.
     */
    public Type erasure() {
	if (tag <= lastBaseTag) return this; /*fast special case*/
	else return map(erasureFun);
    }
    
    public static List<Type> erasure(List<Type> these) {
	return map(these, erasureFun);
    }

    static Mapping erasureFun = new Mapping () {
	public Type apply(Type t) { return t.erasure(); }
    };

    /** Does this type contain occurrences of type `elem'?
     */
    public boolean contains(Type elem) {
	return elem == this;
    }

    public static boolean contains(List<Type> these, Type elem) {
	for (List<Type> l = these;
	     l.tail != null /*inlined: l.nonEmpty()*/;
	     l = l.tail)
	    if (l.head.contains(elem)) return true;
	return false;
    }

    /** Does this type contain an occurrence of some type in `elems'?
     */
    public boolean containsSome(List<Type> elems) {
	for (List<Type> l = elems; l.nonEmpty(); l = l.tail)
	    if (this.contains(elems.head)) return true;
	return false;
    }

    /** Is this type the same as that type?
     */
    public boolean isSameType(Type that) {
	//- System.err.println("_1_" + this + " =? " + that);
	if (this == that) return true;
	if (that.tag >= firstPartialTag) return that.isSameType(this);
	if (that.tag == TYPEARG && that.isExact())
	    return isSameType(that.upperBound());
	switch (this.tag) {
	case BYTE: case CHAR: case SHORT: case INT: case LONG: case FLOAT:
	case DOUBLE: case BOOLEAN: case VOID: case BOT: case NONE:
	    return this.tag == that.tag;
	case TYPEVAR:
	    if (that.isSuperBound() && !that.isExtendsBound())
		return isSameType(that.upperBound());
	    else
		return false;
	default:
	    throw new AssertionError("isSameType " + this.tag);
	}
    }

    /** Same for lists of types, if lists are of different length, return false.
     */
    public static boolean isSameTypes(List<Type> these, List<Type> those) {
	while (these.tail != null && those.tail != null
	       /*inlined: these.nonEmpty() && those.nonEmpty()*/ &&
	       these.head.isSameType(those.head)) {
	    these = these.tail;
	    those = those.tail;
	}
	return these.tail == null && those.tail == null;
        /*inlined: these.isEmpty() && those.isEmpty();*/
    }


    public boolean isSuperBound() { return false; }
    public boolean isExtendsBound() { return false; }
    public boolean isExact() { return true; }
    public boolean isUnbound() { return false; }
    public Type upperBound() { return this; }
    public Type lowerBound() { return this; }
    public Type withTypeVar(Type t) { return this; }

    private static Mapping simplifyArgumentType = new Mapping() {
	public String toString() { return "simplifyArgumentType"; }
	public Type apply(Type t) {
	    if (t.tag == TYPEVAR) {
		TypeVar tv = (TypeVar)t;
		Type bound = tv.bound;
		if (bound != null) {
		    tv.bound = null;
		    tv.bound = bound.map(this);
		}
		return t.map(this);
	    }
	    if (t.tag == TYPEARG) {
		ArgumentType ta = (ArgumentType)t;
		if (ta.isExact())
		    return ta.type.map(this);
		else if (ta.bound != null)
		    ta.bound = (TypeVar)ta.bound.map(this);
		return ta;
	    }
	    return t.map(this);
	}
    };
    public static List<Type> simplifyArgumentType(List<Type> types) {
	return Type.map(types, simplifyArgumentType);
    }
    public Type simplifyArgumentType() {
	return simplifyArgumentType(List.make(this)).head;
    }

    public static List<Type> removeBounds(List<Type> types) {
	ListBuffer<Type> result = new ListBuffer<Type>();
	for(;types.nonEmpty(); types = types.tail) {
	    result.append(types.head.removeBounds());
	}
	return result.toList();
    }
    public Type removeBounds() {
	return this;
    }
    /**
     * OGJ change: This method is very ad-hoc right now, it simply
     * checks if the last parameter in the list of type parameters,
     * belongs to an ogj.ownership package.
     */
    public boolean hasOwnerParameter() {
	Type lastParam = this.allparams().last();
	if (lastParam == null) {
	    return false;
	} else {
	    String name = lastParam.toString();
	    return name.startsWith(com.sun.tools.javac.main.JavaCompiler.ogjPackageName + ".");
	}
    }
    /**
     * OGJ change: This method will go through the parameters and see
     * if any of them are ogj.ownership.Private.
     */
    public boolean hasPrivateOwnerParameter() {
	List<Type> params = this.allparams();
	while (params.nonEmpty()) {
	    String paramName = params.head.toString();
	    if (paramName.startsWith(com.sun.tools.javac.main.JavaCompiler.ogjPackageName + "." +
				     com.sun.tools.javac.main.JavaCompiler.ogjPrefixPrivate)) {
		return true;
	    }
	    if (params.head.hasPrivateOwnerParameter()) {
		return true;
	    }
	    params = params.tail;
	}
	return false;
    }
    /** Is this type a subtype of that type?
     *  (not defined for Method and ForAll types)
     */
    public boolean isSubType(Type that, Warner warn) {
	if (debugSubTyping)
	    System.err.println(" 1 " + this + " <:? " + that);
	if (this == that) return true;
	if (this == that.lowerBound()) return true; // Optimization
	if (that.tag >= firstPartialTag) return that.isSuperType(this);
	if (that.tag == TYPEARG) return this.isSubType(that.lowerBound(), warn);
	switch (this.tag) {
	case BYTE: case CHAR:
	    return (this.tag == that.tag ||
		    this.tag + 2 <= that.tag && that.tag <= DOUBLE);
	case SHORT: case INT: case LONG: case FLOAT: case DOUBLE:
	    return this.tag <= that.tag && that.tag <= DOUBLE;
	case BOOLEAN: case VOID:
	    return this.tag == that.tag;
	case TYPEVAR:
 	    return this.bound().isSubType(that, warn);
	case BOT:
	    return
		that.tag == BOT || that.tag == CLASS ||
		that.tag == ARRAY || that.tag == TYPEVAR;
	default:
	    throw new AssertionError("isSubType " + this.tag);
	}
    }

    /** Is this type a supertype of that type?
     *  overridden for partial types.
     */
    public boolean isSuperType(Type that) {
	return that.isSubType(this);
    }

    /** Is this type a subtype of every type in given list `those'?
     *  (not defined for Method and ForAll types)
     */
    public boolean isSubType(List<Type> those) {
	for (List<Type> l = those; l.nonEmpty(); l = l.tail) {
	    if (!this.isSubType(l.head)) return false;
	}
	return true;
    }

    /** Same for lists of types, if lists are of different length, return false.
     */
    public static boolean isSubTypes(List<Type> these, List<Type> those) {
	while (these.tail != null && those.tail != null
	       /*inlined: these.nonEmpty() && those.nonEmpty()*/ &&
	       these.head.isSubType(those.head)) {
	    these = these.tail;
	    those = those.tail;
	}
	return these.tail == null && those.tail == null;
        /*inlined: these.isEmpty() && those.isEmpty();*/
    }

    /**
     * Same for lists of types, if lists are of different length, return false.
     *
     * OGJ change: this method is new and allows forcing the
     * isSubTypes to accept java.lang.Object as a supertype of
     * ownership parameterised types.
     */
    public static boolean isSubTypes(List<Type> these, List<Type> those, boolean ignoreOwnership) {
	if (ignoreOwnership == false) {
	    return isSubTypes(these, those);
	} else {
	    while (these.tail != null && those.tail != null) {
		if (these.head.hasOwnerParameter() && those.head.isPrimitive()) {
		    break;
		} else if ((these.head.hasOwnerParameter() &&
			    those.head.tsym.fullName() ==
			    those.head.tsym.fullName().table.java_lang_Object) ||
			   (these.head.isSubType(those.head))) {
		    these = these.tail;
		    those = those.tail;
		} else {
		    break;
		}
	    }
	    return these.tail == null && those.tail == null;
	}
    }

    protected static boolean containsType(List<Type> these, List<Type> those) {
	while (these.nonEmpty() && those.nonEmpty()
	       && these.head.containsType(those.head)) {
	    these = these.tail;
	    those = those.tail;
	}
	return these.isEmpty() && those.isEmpty();
    }

    public static boolean containsTypeEquivalent(List<Type> these, List<Type> those) {
	while (these.nonEmpty() && those.nonEmpty()
	       && these.head.containsTypeEquivalent(those.head)) {
	    these = these.tail;
	    those = those.tail;
	}
	return these.isEmpty() && those.isEmpty();
    }

    /** Check if this type contains S.
     *
     * @param S Type to check if contained in this.
     */
    public boolean containsType(Type S) {
	if (debugSubTyping) {
	    System.err.println("  ("+this+").containsType("+S+");");
	    if (S.tag == TYPEARG) {
		System.err.println("    U("+S+") = "+S.upperBound());
		System.err.println("    L("+S+") = "+S.lowerBound());
	    }
	}
	while (S.isExact() && S.tag == TYPEARG)
	    S = S.upperBound();
	return isSameType(S);
    }

    protected boolean containsTypeEquivalent(Type S) {
	return
	    isSameType(S) || // shortcut
	    containsType(S) && S.containsType(this);
    }

    /** If this switch is true, we allow assigning character constants to byte
     *  provided they fit in the range.
     */
    private final static boolean looseInterpretation = true;

    public final boolean isSubType(Type that) {
	return isSubType(that, Warner.noWarnings);
    }

    /** Is this type assignable to that type? Equivalent to subtype
     *  except for constant values. (not defined for Method and ForAll types)
     */
    public boolean isAssignable(Type that, Warner warn) {
	//- System.err.println("  ("+this+").isAssignable("+that+");");//DEBUG
	if (this.tag <= INT && this.constValue != null) {
	    int value = ((Number)this.constValue).intValue();
	    switch (that.tag) {
	    case BYTE:
		if ((looseInterpretation || this.tag != CHAR) &&
		    Byte.MIN_VALUE <= value && value <= Byte.MAX_VALUE)
		    return true;
		break;
	    case CHAR:
		if (Character.MIN_VALUE <= value && value <= Character.MAX_VALUE)
		    return true;
		break;
	    case SHORT:
		if (Short.MIN_VALUE <= value && value <= Short.MAX_VALUE)
		    return true;
		break;
	    case INT:
		return true;
	    }
	}
	return this.isSubType(that, warn);
    }

    /** If this type is castable to that type, return the result of the cast
     *  otherwise return null;
     *  that type is assumed to be an erased type.
     *  (not defined for Method and ForAll types).
     */
    public boolean isCastable(Type that, Warner warn) {
	if (that.tag == ERROR) return true;
	switch (this.tag) {
	case BYTE: case CHAR: case SHORT: case INT: case LONG: case FLOAT:
	case DOUBLE:
	    return that.tag <= DOUBLE;
	case BOOLEAN:
	    return that.tag == BOOLEAN;
	case VOID:
	    return false;
	case BOT:
	    return this.isSubType(that);
	default:
	    throw new AssertionError();
	}
    }

    public boolean intersectsType(Type that, Warner warn) {
	return isCastable(that, warn);
    }

    /** The underlying method type of this type.
     */
    public MethodType asMethodType() { throw new AssertionError(); }

    /** Does this type have the same arguments as that type?
     *  It is assumed that both types are (possibly polymorphic) method types.
     *  Monomorphic method types "have the same arguments",
     *  if their argument lists are equal.
     *  Polymorphic method types "have the same arguments",
     *  if they have the same arguments after renaming all type variables
     *  of one to corresponding type variables in the other, where
     *  correspondence is by position in the type parameter list.
     */
    public boolean hasSameArgs(Type that) { throw new AssertionError(); }

    /** Complete loading all classes in this type.
     */
    public void complete() {}

    public Object clone() {
	try {
	    return super.clone();
	} catch (CloneNotSupportedException e) {
	    throw new AssertionError(e);
	}
    }

    /** An empty list of types.
     */
    public static final List<Type> emptyList = new List<Type>();

    /** VGJ: The class of type arguments. */
    public static class ArgumentType extends Type {

	public Type type;
	public BoundKind kind;
        private Symtab syms;
	public TypeVar bound;

	public void accept(Visitor v) {
	    v.visitArgumentType(this);
	}

        public boolean isArray() {
            return upperBound().isArray();
        }

        public Type elemtype() {
            return upperBound().elemtype();
        }

	public ArgumentType(Type type, BoundKind kind, TypeSymbol tsym, Symtab syms) {
	    super(TYPEARG, tsym);
	    this.kind = kind;
	    this.type = type;
            this.syms = syms;
	}
	public ArgumentType(ArgumentType that, TypeVar bound) {
	    this(that.type, that.kind, that.tsym, that.syms, bound);
	}

	public ArgumentType(Type type, BoundKind kind, TypeSymbol tsym, Symtab syms, TypeVar bound) {
	    this(type, kind, tsym, syms);
	    this.bound = bound;
	}

	public boolean isSameType(Type that) {
	    if (that.tag >= firstPartialTag) return that.isSameType(this);
	    if (isExact() && that.isExact())
		return type.isSameType(that.lowerBound());
            return false;
	}

	public boolean isSuperBound() {
	    return kind == SUPER ||
		kind == UNBOUND;
	}
	public boolean isExtendsBound() {
	    return kind == EXTENDS ||
		kind == UNBOUND;
	}
	public boolean isExact() {
	    return kind == EXACT;
	}
	public boolean isUnbound() {
	    return kind == EXACT;
	}
	public Type upperBound() {
	    if (isSuperBound()) {
		if (bound == null)
		    return syms.objectType;
		else
		    return bound.bound;
	    } else {
		return type;
	    }
	}
	public Type lowerBound() {
	    return isExtendsBound() ? syms.botType : type;
	}

	public boolean isCastable(Type that, Warner warn) {
	    if (debugSubTyping)
		System.err.println("("+this+").isCastable("+that+")");
	    return upperBound().isCastable(that, warn);
	}

	public boolean intersectsType(Type that, Warner warn) {
	    if ((that.isExact() && (that.upperBound().tsym.flags() & INTERFACE) != 0))
		return true; // interfaces always intersect type arguments
	    if ((that.isExact() && (that.upperBound().tag == TYPEVAR))) {
		return that.upperBound().intersectsType(this, warn);
	    }
	    if (isExact() && upperBound().tag == TYPEVAR) {
		return this.upperBound().intersectsType(that, warn);
	    }
	    Type U = this.upperBound();  // U
	    Type L = this.lowerBound();  // L
	    Type Up = that.upperBound(); // U'
	    Type Lp = that.lowerBound(); // L'
	    // System.out.println("[" + U + ".." + L + "] -> [" + Up + ".." + Lp + "]");
	    return (L.isSubType(Lp) && Lp.isSubType(U))  // L <: L' <: U
		|| (L.isSubType(Up) && Up.isSubType(U))  // L <: U' <: U
		|| (Lp.isSubType(L) && L.isSubType(Up))  // L' <: L <: U'
		|| (Lp.isSubType(U) && U.isSubType(Up)); // L' <: U <: U'
	}
	
	/** Check if this type contains S.
	 *
	 * T contains S if:
	 *
	 * L(T) <: L(S) && U(S) <: U(T)
	 *
	 * This relation is only used by ClassType.isSubType(), i.e.
	 *
	 * C<S> <: C<T> if T contains S.
	 *
	 * Because of F-bounds, this relation can lead to infinite
	 * recursion.  Thus we must somehow break that recursion.
	 * Notice that containsType() is only called from
	 * ClassType.isSubType().  Since the arguments has already
	 * been checked against their bounds, we know:
	 *
	 * U(S) <: U(T) if T is "super" bound (U(T) *is* the bound)
	 *
	 * L(T) <: L(S) if T is "extends" bound (L(T) is bottom)
	 *
	 * @param S Type to check if contained in this.
	 */
	public boolean containsType(Type S) {
	    if (debugSubTyping) {
		System.err.println("  ("+this+").containsType("+S+");");
		System.err.println("    U("+this+") = "+this.upperBound());
		System.err.println("    L("+this+") = "+this.lowerBound());
		System.err.println("    U("+S+") = "+S.upperBound());
		System.err.println("    L("+S+") = "+S.lowerBound());
	    }
	    if (isExact() && S.isExact())
		return isSameType(S);
	    return
		(isExtendsBound() || type.isSubType(S.lowerBound())) &&
		(isSuperBound() || S.upperBound().isSubType(type));
	}

	public boolean isSubType(Type that, Warner warn) {
	    if (debugSubTyping) {
		System.err.println(" 5 "+this+" <:? "+that);
		System.err.println("   U("+this+") = "+this.upperBound());
		System.err.println("   L("+that+") = "+that.lowerBound());
	    }
	    return this.upperBound().isSubType(that.lowerBound(), warn);
	}

	public Type withTypeVar(Type t) {
	    //-System.err.println(this+".withTypeVar("+t+");");//DEBUG
	    if (bound == t)
		return this;
	    bound = (TypeVar)t;
	    return this;
	}

	boolean isPrintingBound = false;
	public String toString() {
	    StringBuffer s = new StringBuffer();
	    if (kind == UNBOUND) {
		s.append("?");
	    } else {
		if (!type.isExact())
		    s.append(""+kind); // FIXME!!!
		else if (kind != EXACT)
		    s.append(""+kind);
		s.append(type);
	    }
	    if (moreInfo && bound != null && !isPrintingBound)
		try {
		    isPrintingBound = true;
		    s.append("{:").append(bound.bound).append(":}");
		} finally {
		    isPrintingBound = false;
		}
	    return s.toString();
	}

        public Type subst(List<Type> from, List<Type> to) {
            Type t = type;
	    //- System.err.println("((ArgumentType)"+this+").subst("+from+", "+to+")");//DEBUG
	    //- System.err.println("   "+this+" has bound "+type.bound());//DEBUG
            if (kind != UNBOUND)
		t = type.subst(from,to);
	    if (t == type)
		return this;
	    else if (t.tag == TYPEARG && isExact() && t.isExact())
		return t;
	    else
		return new ArgumentType(t, kind, tsym, syms, bound);
        }

	public Type erasure() {
	    return upperBound().erasure();
	}

	public Type map(Mapping f) {
	    //- System.err.println("   (" + this + ").map(" + f + ")");//DEBUG
	    Type t = type;
	    if (t != null)
		t = f.apply(t);
	    if (t == type)
		return this;
	    else
		return new ArgumentType(t, kind, tsym, syms, bound);
	}

	public Type memberType(Symbol sym) {
	    if (debugSubTyping)
		System.err.println("(" + this + ").memberType("+sym+")");
	    return upperBound().memberType(sym);
	}

	public Type removeBounds() {
	    if (isUnbound()) return this;
	    else return type;
	}
    }

    public static class ClassType extends Type {

	/** The enclosing type of this type. If this is the type of an inner
	 *  class, outer_field refers to the type of its enclosing
	 *  instance class, in all other cases it referes to noType.
	 */
	public Type outer_field;

	/** The type parameters of this type (to be set once class is loaded).
	 */
	public List<Type> typarams_field;

	/** A cache variable for the type parameters of this type,
	 *  appended to all parameters of its enclosing class.
	 *  @see allparams()
	 */
	public List<Type> allparams_field;

	/** The supertype of this class (to be set once class is loaded).
	 */
	public Type supertype_field;

	/** The interfaces of this class (to be set once class is loaded).
	 */
	public List<Type> interfaces_field;

        public ClassType(Type outer, List<Type> typarams, TypeSymbol tsym) {
	    super(CLASS, tsym);
	    this.outer_field = outer;
	    this.typarams_field = typarams;
	    this.allparams_field = null;
	    this.supertype_field = null;
	    this.interfaces_field = null;
	}

	public void accept(Visitor v) {
	    v.visitClassType(this);
	}

	/** make a compound type from non-empty list of types
	 * @param bounds            the types from which the compound type is formed
	 * @param tsym              the compound type's type symbol
	 * @param supertype         is objectType if all bounds are interfaces,
	 *                          null otherwise.
	 */
	static Type makeCompoundType(List<Type> bounds, TypeSymbol tsym, 
				     Type supertype) {
	    ClassSymbol bc = new ClassSymbol(
                ABSTRACT|PUBLIC|SYNTHETIC|COMPOUND|ACYCLIC, tsym.name, tsym);
	    bc.erasure_field = bounds.head.erasure();
	    bc.members_field = new Scope(bc); 
	    ClassType bt = (ClassType)bc.type;
	    bt.allparams_field = Type.emptyList;
	    if (supertype != null) {
		bt.supertype_field = supertype;
		bt.interfaces_field = bounds;
	    } else {
		bt.supertype_field = bounds.head;
		bt.interfaces_field = bounds.tail;
	    }
	    return bt;
	}

	/** Same as previous function, except that third parameter is 
	 *  computed directly. Note that this test might cause a symbol completion.
	 *  Hence, this version of makeCompoundType may not be called during
	 *  a classfile read.
	 */
	public static Type makeCompoundType(List<Type> bounds, TypeSymbol tsym) {
	    Type supertype = (bounds.head.tsym.flags() & INTERFACE) != 0 ?
		bounds.head.supertype() : null;
	    return makeCompoundType(bounds, tsym, supertype);
	}

        public Type constType(Object constValue) {
	    Type t = new ClassType(outer_field, typarams_field, tsym);
	    t.constValue = constValue;
	    return t;
	}

        /** The Java source which this type represents.
	 */
	public String toString() {
	    StringBuffer buf = new StringBuffer();
	    if (outer().tag == CLASS && tsym.owner.kind == TYP) {
		buf.append(outer().toString());
		buf.append(".");
		buf.append(className(tsym, false));
	    } else {
		buf.append(className(tsym, true));
	    }
	    if (typarams().nonEmpty()) {
		buf.append('<');
		buf.append(typarams().toString());
		buf.append(">");
	    }
	    return buf.toString();
	}
//where
            private String className(Symbol sym, boolean longform) {
		if (sym.name.len == 0 && (sym.flags() & COMPOUND) != 0) {
		    StringBuffer s = new StringBuffer(supertype_field.toString());
		    for (List<Type> is=interfaces_field; is.nonEmpty(); is = is.tail) {
			s.append("&");
			s.append(is.head.toString());
		    }
		    return s.toString();
		} else if (sym.name.len == 0) {
		    String s;
		    if (sym.type.interfaces().nonEmpty()) {
			s = Log.getLocalizedString("anonymous.class",
						   sym.type.interfaces().head);
		    } else {
			s = Log.getLocalizedString("anonymous.class",
						   sym.type.supertype());
		    }
		    if (moreInfo)
			s += String.valueOf(sym.hashCode());
		    return s;
		} else if (longform) {
		    return sym.fullName().toString();
		} else {
		    return sym.name.toString();
		}
	    }

        public List<Type> typarams() {
	    if (typarams_field == null) {
		complete();
		typarams_field = tsym.type.typarams();
	    }
	    return typarams_field;
	}

        public Type outer() {
	    if (outer_field == null) {
		complete();
		outer_field = tsym.type.outer();
	    }
	    return outer_field;
	}

        public Type supertype() {
	    if (supertype_field == null) {
		complete();
		Type st = ((ClassType)tsym.type).supertype_field;
		if (st == null) {
		    supertype_field = noType;
		} else if (this == tsym.type) {
		    supertype_field = st; // NOOP!!!
		} else {
		    List<Type> ownparams = classBound().allparams();
		    List<Type> symparams = tsym.type.allparams();
		    supertype_field = 
			(ownparams.isEmpty() && symparams.nonEmpty()) 
			? st.erasure() 
			: st.subst(symparams, ownparams);
		}
	    }
	    return supertype_field;
	}

        public List<Type> interfaces() {
	    if (interfaces_field == null) {
		complete();
		List<Type> is = ((ClassType)tsym.type).interfaces_field;
		if (is == null) {
		    interfaces_field = Type.emptyList;
		} else if (this == tsym.type) {
		    interfaces_field = is;
		} else {
		    List<Type> ownparams = allparams();
		    List<Type> symparams = tsym.type.allparams();
		    interfaces_field = 
			(ownparams.isEmpty() && symparams.nonEmpty()) 
			? erasure(is)
			: subst(is, symparams, ownparams);
		}
	    }
	    return interfaces_field;
	}

        public List<Type> allparams() {
	    if (allparams_field == null) {
		allparams_field = typarams().prependList(outer().allparams());
	    }
	    return allparams_field;
	}

	public Type asSuper(Symbol sym) {
	    if (tsym == sym) {
		return this;
	    } else {
		Type st = supertype();
		if (st.tag == CLASS || st.tag == ERROR) {
		    Type t = st.asSuper(sym);
		    if (t != null) return t;
		}
		if ((sym.flags() & INTERFACE) != 0) {
		    for (List<Type> l = interfaces(); l.nonEmpty(); l = l.tail) {
			Type t = l.head.asSuper(sym);
			if (t != null) return t;
		    }
		}
		return null;
	    }
	}

        public Type asOuterSuper(Symbol sym) {
	    Type t = this;
	    do {
		Type s = t.asSuper(sym);
		if (s != null) return s;
		t = t.outer();
	    } while (t.tag == CLASS);
	    return null;
	}

        public Type classBound() {
	    Type outer1 = outer().classBound();
	    if (outer1 != outer_field)
		return new ClassType(outer1, typarams(), tsym);
	    else
		return this;
	}

	public Type asSub(Symbol sym) {
	    if (tsym == sym) {
		return this;
	    } else {
		Type base = sym.type.asSuper(tsym);
		if (base == null) return null;
		ListBuffer<Type> from = new ListBuffer<Type>();
		ListBuffer<Type> to = new ListBuffer<Type>();
		adapt(base, this, from, to);
		Type res = sym.type.subst(from.toList(), to.toList());
		if (!res.isSubType(this)) return null;
		for (List<Type> l = sym.type.allparams();
		     l.nonEmpty(); l = l.tail)
		    if (res.contains(l.head) && !this.contains(l.head))
			return res.erasure();
		return res;
	    }
	}
//where
          /** Adapt a type by computing a substitution which 
           *  maps a source type to a target type.
	   *  @param from      the source type
	   *  @param target    the target type
	   *  @param from      the type variables of the computed substitution
	   *  @param to        the types of the computed substitution.
	   */
	  private static void adapt(Type source, Type target, 
				    ListBuffer<Type> from, ListBuffer<Type> to) {
	      if (source.tag == TYPEVAR) {
		  from.append(source); 
		  to.append(target);
	      } else if (source.tag == TYPEARG && source.isExact() && source.upperBound().tag == TYPEVAR) {
		  //FIXME(VFORCE) XXX XXX XXX XXX related to casts
		  from.append(((ArgumentType)source).type); 
		  to.append(target);
	      } else if (source.tag == target.tag) {
		  switch (source.tag) {
		  case CLASS: 
		      adapt(source.allparams(), target.allparams(), from, to);
		      break;
		  case ARRAY: 
		      adapt(source.elemtype(), target.elemtype(), from, to);
		  }
	      }
	  }

          /** Adapt a type by computing a substitution which 
	   *  maps a list of source types to a list of target types.
	   *  @param source    the source type
	   *  @param target    the target type
	   *  @param from      the type variables of the computed substitution
	   *  @param to        the types of the computed substitution.
	   */
	  private static void adapt(List<Type> source, List<Type> target,
				    ListBuffer<Type> from, ListBuffer<Type> to) {
	      if (source.length() == target.length()) {
		  while (source.nonEmpty()) {
		      adapt(source.head, target.head, from, to);
		      source = source.tail;
		      target = target.tail;
		  }
	      }
	  }

	public Type memberType(Symbol sym) {
	    Symbol owner = sym.owner;
	    long flags = sym.flags();
	    if (((flags & STATIC) == 0) && owner.type.isParameterized()) {
		Type base = this.asOuterSuper(owner);
		if (base != null) {
		    List<Type> ownerParams = owner.type.allparams();
		    List<Type> baseParams = base.allparams();
		    if (ownerParams.nonEmpty()) {
			if (baseParams.isEmpty()) {
			    // then base is a raw type
			    return sym.type.erasure();
			} else {
			    return sym.type.subst(ownerParams, baseParams);
			}
		    }
		}
	    }
	    return sym.type;
	}

	public Type subst(List<Type> from, List<Type> to) {
	    if (from.tail == null /*inlined from.isEmpty()*/) {
		return this;
	    } else if ((tsym.flags() & COMPOUND) == 0) {
		Type outer = outer();
		List<Type> typarams = typarams();
		List<Type> typarams1 = subst(typarams, from, to);
		Type outer1 = outer.subst(from, to);
		if (typarams1 == typarams && outer1 == outer) return this;
		else return new ClassType(outer1, typarams1, tsym);
	    } else {
		Type st = supertype().subst(from, to);
		List<Type> is = subst(interfaces(), from, to);
		if (st == supertype() && is == interfaces()) return this;
		else return makeCompoundType(is.prepend(st), tsym);
	    }
	}

        public boolean isErroneous() {
	    return 
		outer().isErroneous() || 
		isErroneous(typarams()) ||
		this != tsym.type && tsym.type.isErroneous();
	}

        public boolean isParameterized() {
	    return allparams().tail != null;
            // optimization, was: allparams().nonEmpty();
	}

	/** A cache for the rank. */
	private int rank_field = -1;

	/** The rank of a class is the length of the longest path to Object
	 *  in the class inheritance graph.
	 */
        public int rank() {
	    if (rank_field < 0) {
		Name fullname = tsym.fullName();
		if (fullname == fullname.table.java_lang_Object)
		    rank_field = 0;
		else {
		    int r = supertype().rank();
		    for (List<Type> l = interfaces();
			 l.nonEmpty();
			 l = l.tail) {
			if (l.head.rank() > r) r = l.head.rank();
		    }
		    rank_field = r + 1;
		}
	    }
	    return rank_field;
	}

	public boolean areSupersReifiable() {
	    Type current = this;
	    while (current != null) {
		if (!current.isReifiable())
		    return false;
		current = current.supertype();
	    }
	    return true;
	}

	public boolean isReifiable() {
	    return !isParameterized();
	}

	/** A class type is raw if it misses some
	 *  of its type parameter sections.
	 *  After validation, this is equivalent to:
	 *  allparams.isEmpty() && tsym.type.allparams.nonEmpty();
	 */
        public boolean isRaw() {
	    return
		this != tsym.type // necessary, but not sufficient condition
		&&
		tsym.type.allparams().nonEmpty() &&
		allparams().isEmpty() // necessary, but not sufficient condition
		&&
		(tsym.type.typarams().nonEmpty() && typarams().isEmpty() ||
		 outer().isRaw()); // precise condition, slow to check;
	}

        public Type erasure() {
	    return tsym.erasure();
	}

	public Type map(Mapping f) {
	    Type outer = outer();
	    Type outer1 = f.apply(outer);
	    List<Type> typarams = typarams();
	    List<Type> typarams1 = map(typarams, f);
	    if (outer1 == outer && typarams1 == typarams) return this;
	    else return new ClassType(outer1, typarams1, tsym);
	}

        public boolean contains(Type elem) {
	    return 
		elem == this 
		|| (isParameterized()
		    && (outer().contains(elem) || contains(typarams(), elem)));
	}

        public boolean isSameType(Type that) {
	    //- System.err.println("_2_" + this + " =? " + that);//DEBUG
	    if (this == that) return true;
	    if (that.tag >= firstPartialTag) return that.isSameType(this);
	    if (that.isSuperBound() && !that.isExtendsBound())
		return isSameType(that.upperBound());
	    if (that.tag == TYPEARG && that.isExact())
		return isSameType(that.upperBound());
	    return
		this.tsym == that.tsym &&
		this.outer().isSameType(that.outer()) &&
		containsTypeEquivalent(this.typarams(), that.typarams());
	}

	/**
	 * OGJ change: Prevent casting to and from raw types.
	 */
        public boolean isSubType(Type that, Warner warn) {
	    if (debugSubTyping)
		System.err.println(" 3 " + this + " <:? " + that);
	    if (this == that) return true;
	    if (this == that.lowerBound()) return true; // Optimization
	    if (that.tag >= firstPartialTag) return that.isSuperType(this);
	    if (that.tag == TYPEARG)
		return isSubType(that.lowerBound(), warn);
	    if (this.tsym == that.tsym) {
		if (!that.isParameterized()) {
		    if (this.isParameterized()) {
			// This is not a raw type, while that is a raw
			// type, we need to take special care of this.

			// Check if this has an owner parameter.
			if (this.hasOwnerParameter() && !that.isPrimitive()) {
			    // This cast should not be allowed,
			    // therefore we should fail the subtyping
			    // test.
			    System.out.println("OGJ ERROR: " + this + " has an owner parameter, " +
					       "while " + that + " doesn't. Thus, the former is " +
					       "not a subtype of the latter.");
			    return false;
			} else {
			    return this.outer().isSubType(that.outer(), warn);
			}
		    } else {
			return this.outer().isSubType(that.outer(), warn);
		    }
		} else {
		    if (!this.isParameterized()) {
			// That is not a raw type, while this is raw
			// type, we need to take special care of that.

			// Check if that has an owner parameter.
			if (that.hasOwnerParameter() && !this.isPrimitive()) {
			    // This cast should not be allowed,
			    // therefore we should fail the subtyping
			    // test.
			    System.out.println("OGJ ERROR: " + that + " has an owner parameter, " +
					       "while " + this + " doesn't. Thus, the latter is " +
					       "not a subtype of the former.");
			    return false;
			} else {
			    return containsType(that.typarams(), this.typarams()) &&
				this.outer().isSubType(that.outer(), warn);
			}
		    } else {
			// You're not allowed to write
			//     Vector<String> vec = new Vector<Object>();
			// But with wildcards you can write
			//     Vector<? extends String> vec = new Vector<Object>();
			// which means that subtype checking must be done
			// here instead of same-type checking.
			return containsType(that.typarams(), this.typarams()) &&
			    this.outer().isSubType(that.outer(), warn);
		    }
		}
	    }
	    if ((that.tsym.flags() & INTERFACE) != 0)
		for (List<Type> is = this.interfaces();
		     is.nonEmpty();
		     is = is.tail)
		    if (is.head.isSubType(that, warn)) return true;
	    Type st = this.supertype();
	    // OGJ: We have a check in here, if this has an owner
	    // parameter, then its supertype better have one
	    // too. Otherwise we fail.
	    if (this.hasOwnerParameter() && !st.hasOwnerParameter()) {
		System.out.println("OGJ ERROR: " + this + " has an owner parameter, " +
				   "while its supertype " + st + " doesn't. Thus, we " +
				   "can't carry on checking the subtyping and should fail.");
		return false;
	    }
	    if (st.tag == CLASS && st.isSubType(that, warn))
		return true;
	    return st.isErroneous();
	}

	public boolean intersectsType(Type that, Warner warn) {
	    if (that.tag == TYPEARG) {
		return that.intersectsType(this, warn);
	    } else {
		return isCastable(that, warn);
	    }
	}

	/** The rules for castability are extended to parameterized types
	 *  as follows:
	 *  (1) One may always cast to a supertype
	 *  (2) One may cast to a subtype C<...> provided there is only
	 *      one type with the subtype's class part, C, that is a subtype
	 *      of this type. (This is equivalent to: C<...> = this.asSub(C).
	 *  (3) One may cast an interface to an unparameterized class.
	 *  (4) One may cast a non-final class to an unparameterized interface.
	 */
        public boolean isCastable(Type _that, Warner warn) {
	    Type that = _that;
	    if (debugSubTyping) {
		System.err.println("("+this+").isCastable("+that+")");
		if (isSubType(that)) {
		    System.err.println("("+this+") is subtype of ("+that+")");
		} else {
		    System.err.println("("+this+") is !subtype of ("+that+")");
		}
		if (that.isSubType(this)) {
		    System.err.println("("+that+") is subtype of ("+this+")");
		} else {
		    System.err.println("("+that+") is !subtype of ("+this+")");
		}
	    }
	    boolean result = false, typevarWarning = false;
	    if (that.tag == TYPEVAR) {
		that = that.bound();
		typevarWarning = true;
	    }
	    if (that.tag == ERROR) {
		return true;
	    } else if (that.tag == CLASS || that.tag == ARRAY) {
		if (this.isSubType(that, Warner.noWarnings)) {
		    result = true;
		} else if ((!this.hasOwnerParameter() && !that.hasOwnerParameter())
			   && (that.erasure().isSubType(this.erasure(), Warner.noWarnings) &&
			       isDowncastable(that, warn))) {
		    // OGJ: We can only do erasures if the owner
		    // parameters are not involved.
		    result = true;
		} else if (that.tag == CLASS && that.allparams().isEmpty()) {
		    if ((that.tsym.flags() & INTERFACE) != 0 &&
			(this.tsym.flags() & FINAL) == 0) {
			result = true;
		    } else if ((this.tsym.flags() & INTERFACE) != 0 &&
			       (that.tsym.flags() & FINAL) == 0) {
			result = true;
		    }
		}
	    }
	    if (result && typevarWarning) {
		warn.warnUnchecked("unchecked.cast.to.type", _that);
	    }
	    return result;
	}

	public boolean isDowncastable(Type that, Warner warn) {
	    if (that.tag == ARRAY) {
		return true;
	    } else {
		Type thisAsThat = this.asSub(that.tsym);
		if (thisAsThat != null) {
		    if (!thisAsThat.isParameterized()) {
			return true;
		    } else {
			List<Type> these = thisAsThat.typarams();
			List<Type> those = that.typarams();
			while (these.nonEmpty() && those.nonEmpty()) {
			    if (!these.head.normalize().intersectsType(those.head.normalize(), warn))
				return false;
			    these = these.tail;
			    those = those.tail;			    
			}
			return true;
		    }
		}
	    }
	    return false;
	}

	public void complete() {
	    if (tsym.completer != null) tsym.complete();
	}
	
    }

    public static class ArrayType extends Type {

	public Type elemtype;
	public boolean unsafe = false;
	public boolean basic = false;

        public ArrayType(Type elemtype, TypeSymbol arrayClass) {
            this(elemtype, true, arrayClass);
        }

        public ArrayType(Type elemtype, boolean unsafe, TypeSymbol arrayClass) {
	    super(ARRAY, arrayClass);
	    this.elemtype = elemtype;
	    // All basic types are unsafe
	    switch (elemtype.tag) {
	    case CLASS: case ARRAY:
		this.unsafe = unsafe;
		break;
	    case TYPEVAR: case TYPEARG:
		this.unsafe = unsafe;
		break;
	    default:
		this.unsafe = this.basic = true;
		break;
	    }
	}

	public void accept(Visitor v) {
	    v.visitArrayType(this);
	}

        public boolean isArray() {
            return true;
        }

	public boolean isUnsafe() {
	    return unsafe && (elemtype.tag > lastBaseTag);
	}

	public boolean isSafe() {
	    return !unsafe;
	}

	public boolean areSubsReifiable() {
	    return isReifiable();
	}

	// FIXME(VFORCE): Move the tests on type arguments into the
	// type arguments themselves.
	public boolean isReifiable() {
	    if (unsafe) return true;
	    if (elemtype.isSuperBound()) return false;
	    else if (elemtype.isExtendsBound()) 
		return elemtype.upperBound().areSubsReifiable();
	    else return false;
	}

        public String toString() {
	    return getInnerElementType() + getBrackets();
	}

	public String getBrackets() {
	    Type elem = elemtype;
	    String brac = unsafe ? "[]" : "[=]";
	    if (elem.tag == TYPEARG) {
		char tag;
		BoundKind kind = ((ArgumentType) elem).kind;
		switch (kind) {
		case EXACT: tag='='; break;
		case SUPER: tag='-'; break;
		case EXTENDS: tag='+'; break;
		case UNBOUND: tag='*'; break;
		default: throw new AssertionError(kind);
		}
		brac = "[" + tag + "]";
		elem = ((ArgumentType) elem).type;
	    }
	    if (elem.tag == ARRAY)
		brac += ((ArrayType) elem).getBrackets();
	    return brac;
	}

	private String getInnerElementType() {
	    Type elem = elemtype;
	    if (elem.tag == TYPEARG)
		elem = ((ArgumentType) elem).type;
	    if (elem.tag == ARRAY)
		return ((ArrayType) elem).getInnerElementType();
	    else return elem.toString();		    
	}

	public boolean equals(Object that) {
	    return
		this == that ||
		(that instanceof ArrayType &&
		 this.elemtype.equals(((ArrayType)that).elemtype));
	}

	public int hashCode() {
	    return (ARRAY << 5) + elemtype.hashCode();
	}

        public Type elemtype() { return elemtype; }
	public int dimensions() {
	    int result = 0;
	    for (Type t = this; t.tag == ARRAY; t = t.elemtype()) {
		result++;
	    }
	    return result;
	}
        public List<Type> allparams() { return elemtype.allparams(); }

        public Type subst(List<Type> from, List<Type> to) {
	    if (from.tail == null /*inlined from.isEmpty()*/) {
		return this;
	    } else {
		Type elemtype1 = elemtype.subst(from, to);
		if (elemtype1 == elemtype) return this;
		else return new ArrayType(elemtype1, unsafe, tsym);
	    }
	}

        public boolean isErroneous() {
	    return elemtype.isErroneous();
	}

        public boolean isParameterized() {
	    return elemtype.isParameterized();
	}

        public boolean isRaw() {
	    return elemtype.isRaw();
	}

	public Type erasure() {
	    // Cannot use map(), since the unsafe flag must be set
	    Type elemtype1 = elemtype.erasure();
	    if (elemtype1 == elemtype && unsafe) return this;
	    return new ArrayType(elemtype1, true, tsym);
	}

	public Type map(Mapping f) {
	    Type elemtype1 = f.apply(elemtype);
	    if (elemtype1 == elemtype) return this;
	    else return new ArrayType(elemtype1, unsafe, tsym);
	}

        public boolean contains(Type elem) {
	    return elem == this || elemtype.contains(elem);
	}

	public Type asSuper(Symbol sym) {
	    return (this.isSubType(sym.type)) ? sym.type : null;
	}

	public Type asOuterSuper(Symbol sym) {
	    return (this.isSubType(sym.type)) ? sym.type : null;
	}

        public boolean isSameType(Type that) {
	//- System.err.println("_3_" + this + " =? " + that);
	    if (this == that) return true;
	    if (that.tag >= firstPartialTag) return that.isSameType(this);
	    if (that.tag == TYPEARG && that.isExact())
		return isSameType(that.upperBound());
	    return that.tag == ARRAY &&
		this.elemtype.containsTypeEquivalent(that.elemtype()) &&
		this.unsafe == ((ArrayType) that).unsafe;
	}

        public boolean isSubType(Type that, Warner warn) {
	    if (debugSubTyping)
		System.err.println(" 4 " + this + " <:? " + that);
	    if (this == that) return true;
	    if (this == that.lowerBound()) return true; // Optimization
	    if (that.tag >= firstPartialTag) return that.isSuperType(this);
	    if (that.tag == TYPEARG) return this.isSubType(that.lowerBound(), warn);
	    if (that.tag == ARRAY) {
		ArrayType athat = (ArrayType) that;
		if (this.elemtype.tag <= lastBaseTag) {
		    return this.elemtype.isSameType(that.elemtype());
		}
		if (this.unsafe) {
		    if (athat.unsafe /* [~] <: [~] */) {
			return this.elemtype.isSubType(that.elemtype(), warn);
		    } else if (!that.elemtype().isSuperBound() /* [~] <: [=], [+] */) {
			boolean result = this.elemtype.isSubType(that.elemtype().upperBound(), warn);
			if (result && !that.elemtype().isExtendsBound())
			    warn.warnUnchecked("storecheck"); // [=] := [~]
			return result;
		    } else /* [~] <: [-] */ {
			warn.warnUnchecked("storecheck"); // [-] := [~]
			return true;
		    }
		} else if (athat.unsafe) {
		    if (!this.elemtype().isSuperBound() /* [+], [=] <: [~] */) {
			boolean result = this.elemtype.upperBound().isSubType(that.elemtype(), warn);
			if (result && this.elemtype().isExtendsBound()) /* [~] := [+] */{ 
			    if (!(this.elemtype().upperBound().isSameType(that.elemtype())
				  && that.elemtype().areSubsReifiable())) {
				warn.warnUnchecked("unchecked");
			    }
			} else if (result) /* [~] := [=] */ {
			    if (!this.elemtype().isReifiable())
				warn.warnUnchecked("unchecked");
			}
			return result;
		    } else /* [-] <: [~] */ {
			Symtab syms = ((ArgumentType) this.elemtype()).syms;
			boolean result = that.elemtype().isSameType(syms.objectType); 
			if (result) /* [~] := [-] */ {
			    if (!this.elemtype().lowerBound().areSupersReifiable())
				warn.warnUnchecked("unchecked");
			    if (!this.elemtype().lowerBound().isSameType(syms.objectType))
				warn.warnUnchecked("storecheck");
			}
			return result;
		    }
		} else /* [+], [-], [=] <: [+], [-], [=] */ {
		    return that.elemtype().containsType(this.elemtype);
		}
	    } else if (that.tag == CLASS) {
		Name thatname = that.tsym.fullName();
		Name.Table names = thatname.table;
		return (thatname == names.java_lang_Object ||
			thatname == names.java_lang_Cloneable ||
			thatname == names.java_io_Serializable);
	    } else {
		return false;
	    }
	}

	public boolean intersectsType(Type that, Warner warn) {
	    if (that.tag == TYPEARG) {
		return that.intersectsType(this, warn);
	    } else {
		return this.isCastable(that, warn);
	    }
	}

        public boolean isCastable(Type that, Warner warn) {
	    if (that.tag == ERROR) {
		return true;
	    } else if (that.tag == CLASS && this.isSubType(that, Warner.noWarnings)) {
		return true;
	    } else if (that.isArray()) {
		if (this.elemtype().tag <= lastBaseTag) {
		    return this.elemtype().tag == that.elemtype().tag;
		} else {
		    Type thiselm = this.elemtype().simplifyArgumentType();
		    Type thatelm = that.elemtype().simplifyArgumentType();
		    if (!this.isUnsafe() && !that.isUnsafe()) {
			thiselm = thiselm.normalize();
			thatelm = thatelm.normalize();
		    } else if (this.isUnsafe() && !that.isUnsafe()) {
			return this.unsafeIntersects(that, warn);
		    } else if (that.isUnsafe() && !this.isUnsafe()) {
                        return ((ArrayType) that.upperBound()).unsafeIntersects(this, warn);
		    }
		    return thiselm.intersectsType(thatelm, warn);
		}
	    }
	    return false;
	}

	private boolean unsafeIntersects(Type that, Warner warn) {
	    if (((this.elemtype().tsym.flags() & INTERFACE) != 0) &&
		((that.elemtype().upperBound().tsym.flags() & FINAL) == 0))
		return true;
	    if (that.elemtype().isSuperBound()) {
		return that.elemtype().lowerBound().isSubType(this.elemtype());
	    } else {
		return that.elemtype().upperBound().isSubType(this.elemtype())
		    || this.elemtype().isSubType(that.upperBound());
	    }
	}

	public void complete() {
	    elemtype.complete();
	}
    }

    public static class MethodType extends Type implements Cloneable {

	public List<Type> argtypes;
        public Type restype;
	public List<Type> thrown;

	public MethodType(List<Type> argtypes,
			  Type restype,
			  List<Type> thrown,
			  TypeSymbol methodClass) {
	    super(METHOD, methodClass);
	    this.argtypes = argtypes;
	    this.restype = restype;
	    this.thrown = thrown;
	}

	public void accept(Visitor v) {
	    v.visitMethodType(this);
	}

        private static final Mapping lowerBoundMapping =
            new Mapping() {
                public Type apply(Type that) {
                    return that.lowerBound();
                }
            };

        public List<Type> lowerBoundArgtypes() {
            return map(argtypes, lowerBoundMapping);
        }

        /** The Java source which this type represents.
	 *
	 *  XXX 06/09/99 iris This isn't correct Java syntax, but it probably
	 *  should be.
	 */
	public String toString() {
	    return "(" + argtypes + ")" + restype;
	}

	public boolean equals(Object that) {
	    if (this == that) return true;
	    if (!(that instanceof MethodType)) return false;
	    MethodType mthat = (MethodType)that;
	    List<Type> thisargs = this.argtypes;
	    List<Type> thatargs = mthat.argtypes;
	    while (thisargs.tail != null && thatargs.tail != null
		   /*inlined: thisargs.nonEmpty() && thatargs.nonEmpty()*/ &&
		   thisargs.head.equals(thatargs.head)) {
		thisargs = thisargs.tail;
		thatargs = thatargs.tail;
	    }
	    if (thisargs.tail != null || thatargs.tail != null
		/*inlined: !thisargs.isEmpty() || !thatargs.isEmpty();*/) 
		return false;
	    return this.restype.equals(mthat.restype);
	}

	public int hashCode() {
	    int h = METHOD;
	    for (List<Type> thisargs = this.argtypes;
		 thisargs.tail != null; /*inlined: thisargs.nonEmpty()*/
		 thisargs = thisargs.tail)
		h = (h << 5) + thisargs.head.hashCode();
	    return (h << 5) + this.restype.hashCode();
	}

	public List<Type>        argtypes() { return argtypes; }
	public Type              restype()  { return restype; }
        public List<Type>        thrown()   { return thrown; }

	public void setThrown(List<Type> t) {
	    thrown = t;
	}

	public Type subst(List<Type> from, List<Type> to) {
	    if (from.tail == null /*inlined from.isEmpty()*/) {
		return this;
	    } else {
		List<Type> argtypes1 = subst(argtypes, from, to);
		Type restype1 = restype.subst(from, to);
		List<Type> thrown1 = subst(thrown, from, to);
		if (argtypes1 == argtypes && 
		    restype1 == restype &&
		    thrown1 == thrown) return this;
		else return new MethodType(argtypes1, restype1, thrown1, tsym);
	    }
	}

        public boolean isErroneous() {
	    return isErroneous(argtypes) || restype.isErroneous();
	}

	public Type map(Mapping f) {
	    List<Type> argtypes1 = map(argtypes, f);
	    Type restype1 = f.apply(restype);
	    List<Type> thrown1 = map(thrown, f);
	    if (argtypes1 == argtypes && 
		restype1 == restype &&
		thrown1 == thrown) return this;
	    else return new MethodType(argtypes1, restype1, thrown1, tsym);
	}

        public boolean contains(Type elem) {
	    return elem == this || contains(argtypes, elem) || restype.contains(elem);
	}

        public MethodType asMethodType() { return this; }

        public boolean hasSameArgs(Type that) {
	    return
		that.tag == METHOD &&
		containsTypeEquivalent(this.argtypes, that.argtypes());
	}

	/** isSameType for methods does not take thrown exceptions into account!
	 */
        public boolean isSameType(Type that) {
	    //- System.err.println("_4_" + this + " =? " + that);
	    if (that.tag == TYPEARG && that.isExact())
		return isSameType(that.upperBound());
	    return hasSameArgs(that) && restype.isSameType(that.restype());
	}

	public void complete() {
	    for (List<Type> l = argtypes; l.nonEmpty(); l = l.tail)
		l.head.complete();
	    restype.complete();
	    for (List<Type> l = thrown; l.nonEmpty(); l = l.tail)
		l.head.complete();
	}
    }

    public static class PackageType extends Type {

	PackageType(TypeSymbol tsym) {
	    super(PACKAGE, tsym);
	}

	public void accept(Visitor v) {
	    v.visitPackageType(this);
	}

        public String toString() {
	    return tsym.fullName().toString();
	}

	public boolean isSameType(Type that) {
	    return this == that;
	}
    }

    public static class TypeVar extends Type {

	/** The bound of this type variable; set from outside.
	 *  Must be nonempty once it is set.
	 *  For a bound, `bound' is the bound type itself.
	 *  Multiple bounds are expressed as a single class type which has the
	 *  individual bounds as superclass, respectively interfaces.
	 *  The class type then has as `tsym' a compiler generated class `c', 
	 *  which has a flag COMPOUND and whose owner is the type variable 
	 *  itself. Furthermore, the erasure_field of the class
	 *  points to the first class or interface bound.
	 */
        public Type bound = null; 

	public TypeVar(Name name, Symbol owner) {
	    super(TYPEVAR, null);
	    tsym = new TypeSymbol(0, name, this, owner);
	}

	public TypeVar(TypeSymbol tsym, Type bound) {
	    super(TYPEVAR, tsym);
	    this.bound = bound;
	}

	public void accept(Visitor v) {
	    v.visitTypeVar(this);
	}

	public boolean isReifiable() {
	    return false;
	}

	public String typaramString() {
	    if (bound == null) {
		return toString();
	    } else {
		Name fullname = bound.tsym.fullName();
		return this +
		    ((fullname == fullname.table.java_lang_Object) 
		     ? ""
		     : " extends " + getBounds());
	    }
	}

        public Type bound() { return bound; }

	/** Set bounds field to reflect a (possibly multiple) list of bounds
	 * @param bounds            the bounds, must be nonempty
	 * @param supertype         is objectType if all bounds are interfaces,
	 *                          null otherwise.
	 */ 
	public void setBounds(List<Type> bounds, Type supertype) {
	    if (bounds.tail.isEmpty()) bound = bounds.head;
	    else bound = ClassType.makeCompoundType(bounds, tsym, supertype);
	    rank_field = -1;
	}

	/** Same as previous function, except that second parameter is 
	 *  computed directly. Note that this test might cause a symbol completion.
	 *  Hence, this version of setBounds may not be called during
	 *  a classfile read.
	 */
	public void setBounds(List<Type> bounds) {
	    Type supertype = (bounds.head.tsym.flags() & INTERFACE) != 0 ?
		bounds.head.supertype() : null;
	    setBounds(bounds, supertype);
	    rank_field = -1;
	}

	/** Return list of bounds of this type variable.
	 */ 
	public List<Type> getBounds() {
	    if ((bound.tsym.flags() & COMPOUND) == 0)
	        return emptyList.prepend(bound);
	    else if ((erasure().tsym.flags() & INTERFACE) == 0)
   	        return interfaces().prepend(supertype());
	    else
		// No superclass was given in bounds.
		// In this case, supertype is Object, erasure is first interface.
	        return interfaces();
	}

	/** The supertype is always
	 *  a class type. If the type variable's bounds start with a 
	 *  class type, this is also the supertype. 
	 *  Otherwise, the supertype is java.lang.Object.
	 */
        public Type supertype() {
	    if (bound.tag == TYPEVAR ||
		(bound.tsym.flags() & (INTERFACE | COMPOUND)) == 0)
		return bound;
	    else 
		return bound.supertype();
	}

        public List<Type> interfaces() {
	    long flags = bound.tsym.flags();
	    if ((flags & INTERFACE) != 0) return emptyList.prepend(bound);
	    else if ((flags & COMPOUND) != 0) return bound.interfaces();
	    else return emptyList;
	}

        public Type asSuper(Symbol sym) {
	    return bound.asSuper(sym);
	}

        public Type asOuterSuper(Symbol sym) {
	    return asSuper(sym);
	}

        public Type classBound() {
	    return supertype().classBound();
	}

        public Type memberType(Symbol sym) {
	    return bound.memberType(sym);
	}

	public Type subst(List<Type> from, List<Type> to) {
	    //- System.err.println("   "+this+" has bound "+bound());//DEBUG
	    while (from.length() > to.length()) from = from.tail;
	    while (from.tail != null /*inlined: from.nonEmpty()*/) {
		if (this == from.head) {
		    Type t = to.head;
		    while (t.tag == TYPEARG && t.isExact())
			// If the value we are substituting for this
			// is an exact bound, then remove any implicit
			// ArgumentType wrappers.
			// As this is a type variable, it should have
			// one already.
			t = t.upperBound();
		    return t.withTypeVar(this);
		}
		from = from.tail;
		to = to.tail;
	    }
	    return this;
	}

	public TypeVar substBound(List<Type> from, List<Type> to) {
	    Type bound1 = bound.subst(from, to);
	    if (bound1 == bound) return this;
	    else return new TypeVar(tsym, bound1);
	}

	static public List<Type> substBounds(List<Type> tvars, 
					     final List<Type> from, 
					     final List<Type> to) {
	    return map(tvars, new Mapping () {
		public Type apply(Type t) { 
		    return ((TypeVar)t).substBound(from, to);
		}
	    });	    
	}

	static Mapping newInstanceFun = new Mapping() {
	    public Type apply(Type t) { return new TypeVar(t.tsym, t.bound()); }
	};

	/** Create new vector of type variables from list of variables
	 *  changing all recursive bounds from old to new list.
	 */
	static public List<Type> newInstances(List<Type> tvars) {
	    List<Type> tvars1 = map(tvars, newInstanceFun);
	    for (List<Type> l = tvars1; l.nonEmpty(); l = l.tail) {
		TypeVar tv = (TypeVar) l.head;
		tv.bound = tv.bound.subst(tvars, tvars1);
	    }
	    return tvars1;
	}

	public Type erasure() {
	    return bound.erasure();
	}

	public boolean intersectsType(Type that, Warner warn) {
	    if (that.tag == TYPEARG) {
		// A typevar should act as if it were +bound()
		if (that.isSuperBound()) {
		    return that.lowerBound().isSubType(this.bound()) ||
			this.bound().isSubType(that.lowerBound());
		} else {
		    return that.upperBound().isSubType(this.bound()) ||
			this.bound().isSubType(that.upperBound());
		}
	    } else {
		return this.isCastable(that, warn);
	    }
	}

	public boolean isCastable(Type that, Warner warn) {
	    if (that.tag == ERROR) {
		return true;
	    } else {
		return bound.isCastable(that, warn);
	    }
	}

	private int rank_field = -1;
	public int rank() {
	    if (rank_field < 0) {
		int r = supertype().rank();
		for (List<Type> l = interfaces();
		     l.nonEmpty();
		     l = l.tail) {
		    if (l.head.rank() > r) r = l.head.rank();
		}
		rank_field = r + 1;
	    }
	    return rank_field;
	}
    }

    public static abstract class DelegatedType extends Type {
	public Type qtype;
	public DelegatedType(int tag, Type qtype) {
	    super(tag, qtype.tsym);
	    this.qtype = qtype;
	}
	public String toString() { return qtype.toString(); }
	public List<Type> typarams() { return qtype.typarams(); }
	public Type outer() { return qtype.outer(); }
	public Type elemtype() { return qtype.elemtype(); }
	public List<Type> argtypes() { return qtype.argtypes(); }
	public Type restype() { return qtype.restype(); }
	public List<Type> thrown() { return qtype.thrown(); }
	public Type supertype() { return qtype.supertype(); }
	public List<Type> interfaces() { return qtype.interfaces(); }
	public List<Type> allparams() { return qtype.allparams(); }
	public Type bound() { return qtype.bound(); }
	public Type subst(final List<Type> from, final List<Type> to) { return qtype.subst(from, to); }
	public Object clone() { DelegatedType t = (DelegatedType)super.clone(); t.qtype = (Type)qtype.clone(); return t; }
	public boolean isErroneous() { return qtype.isErroneous(); }
    }

    public static class ForAll extends DelegatedType implements Cloneable {
	public List<Type> tvars;

	public ForAll(List<Type> tvars, Type qtype) {
	    super(FORALL, qtype);
	    this.tvars = tvars;
	}

	public void accept(Visitor v) {
	    v.visitForAll(this);
	}

	public String typaramsString() {
	    StringBuffer s = new StringBuffer();
	    s.append("<" + ((TypeVar)tvars.head).typaramString());
	    for (List<Type> l = tvars.tail; l.nonEmpty(); l = l.tail) {
		s = s.append(", " + ((TypeVar)l.head).typaramString());
	    }
	    return s + ">";
	}

        public String toString() {
	    return typaramsString() + qtype;
	}

	public List<Type>        typarams()   { return tvars; }

	public void setThrown(List<Type> t) {
	    qtype.setThrown(t);
	}

	public Type subst(final List<Type> from, final List<Type> to) { 
	    if (from.tail == null /*inlined from.isEmpty()*/) {
		return this;
	    } else {
		List<Type> tvars1 = TypeVar.substBounds(tvars, from, to);
		Type qtype1 = qtype.subst(from, to);
		if (tvars1 == tvars && qtype1 == qtype) return this;
		else if (tvars1 == tvars) return new ForAll(tvars1, qtype1);
		else return new ForAll(tvars1, qtype1.subst(tvars, tvars1));
	    }
	}

	public Object clone() {
	    ForAll result = (ForAll)super.clone();
	    result.qtype = (Type)result.qtype.clone();
	    return result;
	}

	public boolean isErroneous()  {
	    return qtype.isErroneous();
	}

	public Type map(Mapping f) {
	    return f.apply(qtype);
	}

        public boolean contains(Type elem) {
	    return qtype.contains(elem);
	}

        public MethodType asMethodType() {
	    return qtype.asMethodType();
	}

	/** Does this type have the same bounds for quantified variables
	 *  as that type?
	 */
	boolean hasSameBounds(ForAll that) {
	    List<Type> l1 = this.tvars;
	    List<Type> l2 = that.tvars;
	    while (l1.nonEmpty() && l2.nonEmpty() && 
		   l1.head.bound().isSameType(
		       l2.head.bound().subst(that.tvars, this.tvars))) {
		l1 = l1.tail;
		l2 = l2.tail;
	    }
	    return l1.isEmpty() && l2.isEmpty();
	}

        public boolean isSameType(Type that) {
	    if (that.tag == TYPEARG && that.isExact())
		return isSameType(that.upperBound());
	    return
		that.tag == FORALL &&
		hasSameBounds((ForAll)that) &&
		qtype.isSameType(
		    ((ForAll)that).qtype.subst(((ForAll)that).tvars, tvars));
	}

        public boolean hasSameArgs(Type that) {
	    return
		that.tag == FORALL &&
		hasSameBounds((ForAll)that) &&
		qtype.hasSameArgs(
		    ((ForAll)that).qtype.subst(((ForAll)that).tvars, tvars));
	}

	public void complete() {
	    for (List<Type> l = tvars; l.nonEmpty(); l = l.tail) {
		l.head.supertype().complete();
		for (List<Type> l1 = l.head.interfaces(); 
		     l1.nonEmpty(); l1 = l1.tail) {
		    l1.head.complete();
		}
	    }
	    qtype.complete();
	}
    }

    public static class ErrorType extends ClassType {

	public ErrorType() {
	    super(noType, emptyList, null);
	    tag = ERROR;
	}

	public ErrorType(ClassSymbol c) {
	    this();
	    tsym = c;
	    c.type = this;
	    c.kind = ERR;
	    c.members_field = new Scope.ErrorScope(c);
	}

	public ErrorType(Name name, TypeSymbol container) {
	    this(new ClassSymbol(PUBLIC|STATIC|ACYCLIC, name, null, container));
	}

	public void accept(Visitor v) {
	    v.visitErrorType(this);
	}

        public Type constType(Object constValue) { return this; }
        public Type outer()                      { return this; }
        public Type elemtype()               	 { return this; }
        public Type restype()                	 { return this; }
        public Type asSuper(Symbol sym)      	 { return this; }
        public Type asOuterSuper(Symbol sym) 	 { return this; }
        public Type asSub(Symbol sym)        	 { return this; }
        public Type memberType(Symbol sym)   	 { return this; }
        public Type classBound()		 { return this; }
	public Type subst(List<Type> from, List<Type> to) { return this; }
	public Type map(Mapping f)               { return this; }
	public Type erasure()			 { return this; }
	public Type unerasure()			 { return this; }

        public boolean isGenType(Type that)	 { return true; }
        public boolean isErroneous()         	 { return true; }
        public boolean isSameType(Type that)   	 { return true; }
        public boolean isSubType(Type that, Warner warn)    	 { return true; }
        public boolean isSuperType(Type that)  	 { return true; }
        public boolean isCastable(Type that, Warner warn) { return true; }
        public boolean hasSameArgs(Type that)    { return false; }
	public boolean isAssignable(Type that, Warner warn)   { return true; }

        public List<Type> allparams()		 { return emptyList; }
        public List<Type> typarams()		 { return emptyList; }
	public int rank()                        { return 0; }
    }

    public static abstract class Visitor {
	public void visitClassType(ClassType that) { visitType(that); }
	public void visitArgumentType(ArgumentType that) { visitType(that); }
	public void visitArrayType(ArrayType that) { visitType(that); }
	public void visitMethodType(MethodType that) { visitType(that); }
	public void visitPackageType(PackageType that) { visitType(that); }
	public void visitTypeVar(TypeVar that) { visitType(that); }
	public void visitForAll(ForAll that) { visitType(that); }
	public void visitErrorType(ErrorType that) { visitType(that); }
	public abstract void visitType(Type that);
    }
}
