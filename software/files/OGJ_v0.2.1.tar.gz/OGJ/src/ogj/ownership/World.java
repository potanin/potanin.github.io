/**
 *
 * Class: ogj.ownership.World
 *
 * @author Alex Potanin (alex@mcs.vuw.ac.nz)
 * @version 0.0.1
 *
 * <p>This class is a special class that is used in our ownership
 * hierarchy. It is on the top.
 */


package ogj.ownership;


public interface World {
    /**
     * This method is a current [hacky] way of telling everyone not to
     * implement this.
     */
    public void doNotImplementThisInterface();
}
