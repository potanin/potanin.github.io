/**
 *
 * Class: ogj.ownership.Private
 *
 * @author Alex Potanin (alex@mcs.vuw.ac.nz)
 * @version 0.0.1
 *
 * <p>This class is a special class that is used in our ownership
 * hierarchy. It is used in place of a keyword denoting the current
 * owner.
 */


package ogj.ownership;


public interface Private extends World {
    /**
     * This method is a current [hacky] way of telling everyone not to
     * implement this.
     */
    public void doNotImplementThisInterface();
}
